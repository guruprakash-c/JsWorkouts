<?php 
//error_reporting(0);
require_once "./controller/Posts.php";
require_once "./controller/Miscellaneous.php";
$misc = new Miscellaneous();
$misc->Consent();

$postObj = new Posts();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Learn from Developers</title>
    <?php require_once "./layouts/head.php"; ?>
</head>
<body>
    <!-- <div id="loader">
        <img src="./assets/loading.gif" alt="Loading" />
    </div> -->
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <main class="container mt-5" style="margin-top: 8em !important;">
        <?php 
            $postArticle = $postObj->GetFeatured();
            if(mysqli_num_rows($postArticle)>0){
                while($pData = mysqli_fetch_assoc($postArticle)){
        ?>
            <article class="row">
                <section class="col-md-8">
                    <img src="<?=$pData['Banner'] ?>" style="width: 100%; height: 300px;" class="img-thumbnail border-0 mb-3"
                        alt="<?=$pData['Title'] ?>" title="<?=$pData['Title'] ?>" />
                </section>
                <section class="col-md-4 mt-3 mb-3 farticle">
                    <a href="<?='posts.php?p='.$pData['ID'] ?>" class="mt-0">
                        <h3 class="h3 featured-title"><span class="badge bg-success text-white">Featured</span>&nbsp;<?=$pData['Title'] ?></h3>
                        <p class="featured-muted">
                        <?php 
                            $postSummary = $pData['Summary'];
                            $summarySize = strlen($postSummary);
                            echo substr($postSummary,0,($summarySize < 500)?$summarySize:500).'&hellip;';
                        ?>
                        </p>
                    </a>
                    <div class="media"> 
                        <img src="<?=$pData['AuthorPhoto'] ?>" style="width: 40px; height: 40px;" class="img-thumbnail rounded-circle mr-3 h4 font-weight-bold text-center bg-light" alt="<?=$postObj->AlterNateName($pData['Author']) ?>" title="<?=$pData['Author'] ?>"/>
                        <div class="media-body featured-muted">
                            <h5 class="mt-0"><a href="<?='./search.php?a='.str_replace(' ','',$pData['Author']) ?>"><?=$pData['Author'] ?></a></h5>
                            <time><?=$postObj->JustNowTiming($pData['Date']) ?></time> <?=($pData['Type'] == 'Article') ? '&bull; '.$postObj->ReadingTime($pData['Description']).' to read' : '' ?>
                        </div>
                    </div>
                </section>
            </article>
        <?php            
                }
            }
        ?>
        <?php 
            $postArticles = $postObj->GetPosts('');
                if(mysqli_num_rows($postArticles)>0){
        ?>
            <section class="row articles">
                <?php     
                while($pDatas = mysqli_fetch_assoc($postArticles)){
                ?>
                    <article class="col-md-4 mt-3 mb-3 article">
                        <a href="<?='posts.php?p='.$pDatas['ID'] ?>" class="mt-0">
                            <img src="<?=$pDatas['Banner'] ?>" style="width: 100%; height: 200px;" class="img-thumbnail border-0 mb-3" alt="<?=$pDatas['Title'] ?>" title="<?=$pDatas['Title'] ?>" />
                            <h3 class="h3 article-title"><?=$pDatas['Title'] ?></h3>
                            <p class="featured-muted">
                                <?php 
                                    $postsSummary = $pDatas['Summary'];
                                    $summarySizes = strlen($postsSummary);
                                    echo substr($postsSummary,0,($summarySizes < 200) ? $summarySizes : 200).'&hellip;';
                                ?>
                            </p>
                        </a>
                        <div class="media"> 
                            <img src="<?=$pDatas['AuthorPhoto'] ?>" style="width: 40px; height: 40px;" class="img-thumbnail rounded-circle mr-3 h4 font-weight-bold text-center bg-light" alt="<?=$postObj->AlterNateName($pDatas['Author']) ?>" title="<?=$pDatas['Author'] ?>"/>
                            <div class="media-body featured-muted">
                                <h5 class="mt-0"><a href="<?='./search.php?a='.str_replace(' ','',$pDatas['Author']) ?>"><?=$pDatas['Author'] ?></a></h5>
                                <time><?=$postObj->JustNowTiming($pDatas['Date']) ?></time> <?=($pDatas['Type'] == 'Article') ? '&bull; '.$postObj->ReadingTime($pDatas['Description']).' to read' : '' ?>
                            </div>
                        </div>
                    </article>
                <?php            
                    }
                ?>
            </section>
        <?php 
         }
         else{
        ?>
            <section class="row jumbotron">
                <div class="col-md-12 text-center">
                    <h3 class="h3">Sorry! no article(s) added yet.</h3>
                </div>
                <div class="col-md-12 text-center">
                    <p>Want to add your article?</p>
                </div>
                <div class="col-md-12 text-center md-offset-4">
                    <a href="./contribute.php" role="button" class="btn btn-outline-primary btn-lg">
                        Publish your Article <span class="fa fa-chevron-circle-right"></span>
                    </a>
                </div>
            </section>
        <?php     
         }
        ?>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
    <script>
        Scroller('.articles','.article',3);
    </script>
</body>
</html>
<?php 
//error_reporting(0);
require_once "./controller/Category.php";
require_once "./controller/Posts.php";
require_once "./controller/Miscellaneous.php";

$misc = new Miscellaneous();
$misc->Consent();

session_start();
$categoryObj = new Category();
$cgyPosts = new Posts();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Categories &mdash; Learn from Developers</title>
    <?php require_once "./layouts/head.php"; ?>
</head>
<body>
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <main class="container mt-4 search-body" style="margin-top: 7em !important;">
        <section class="clearfix mb-2">
            <span class="h3 float-left"><span class="fa fa-users mr-1"></span>Categories</span>
            <span class="h3 float-right">
                <?php if(!empty($_SESSION['laererg'])){ ?>
                <button type="button" class="btn btn-success" data-toggle="collapse" data-target="#addcategory" aria-expanded="false" aria-controls="addcategory">
                    <span class="fa fa-plus mr-1"></span>Add Category
                </button>    
                <?php } ?>
            </span>
        </section>
        <?php 
            if(!empty($_SESSION['laererg'])){
            if($_SERVER['REQUEST_METHOD']==='POST'){
                if(!empty($_POST['cTitle']) && !empty($_POST['cIcon']) && !empty($_POST['cBanner'])){
                    $category = array(
                        'Category'=>htmlentities($_POST['cTitle']),
                        'Icon'=>$_POST['cIcon'],
                        'Banner'=>$_POST['cBanner']
                    );
                    $response = $categoryObj->NewCategory($category);
                    switch ($response) {
                        case -1:
                            echo '<div class="alert alert-warning alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> The Category already exists.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                            break;
                        case 0:
                            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> The Category failed to add.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                            break;
                        case 1:
                            echo '<div class="alert alert-success alert-dismissible fade show" role="alert"> <strong>Success!</strong> The Category added.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                            break;
                    }
                }  
            }
        ?>
            <section class="row mt-3" id="addcategory">
                <form name="categoryform" id="categoryform" method="POST" enctype="multipart/form-data" class="col-md-12 mx-auto card">
                    <section class="card-header">
                        <h3>New Category</h3>
                    </section>
                    <section class="card-body"> 
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <label for="cTitle">Category <span class="text-danger">*</span></label>
                                <input type="text" name="cTitle" id="cTitle" placeholder="Category"
                                    class="form-control form-control-sm" maxlength="100"
                                    oninvalid="this.setCustomValidity('Please enter your category name.')"
                                    oninput="this.setCustomValidity('')" required />
                                <p>max. 100 characters</p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <label for="cIcon">Category Icon<span class="text-danger">*</span></label>
                                <input type="url" name="cIcon" id="cIcon" placeholder="Category Icon include http(s)://"
                                    class="form-control form-control-sm imgurl" oninvalid="this.setCustomValidity('Please enter the url of the category icon image.')" oninput="this.setCustomValidity('')" required />
                                <p>*.jpeg,.png,.jpg,.svg are allowed formats</p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <label for="cBanner">Category Banner<span class="text-danger">*</span></label>
                                <input type="url" name="cBanner" id="cBanner" placeholder="Category Banner include http(s)://" class="form-control form-control-sm imgurl"
                                    oninvalid="this.setCustomValidity('Please enter the url of the category banner image.')"
                                    oninput="this.setCustomValidity('')" required />
                                <p>*.jpeg,.png,.jpg,.svg are allowed formats</p>
                            </div>
                        </div>
                    </section>
                    <section class="card-footer">
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <button type="submit" class="btn btn-primary btn-lg mr-1">Add Category</button>
                                <button type="reset" class="btn btn-danger btn-lg ml-1">Cancel</button>
                            </div>
                        </div>
                    </section>
                </form>
            </section>
        <?php        
            }
            if(!empty($_GET['c'])){
                $responses = $cgyPosts->GetSearch("",$_GET['c'],"");
                if($responses != null){
                    if (mysqli_num_rows($responses) > 0) {
                    echo '<p class="lead">about <em class="font-weight-bold">'.mysqli_num_rows($responses).'</em> result(s)</p>';
                    ?>
                    <section class="row mt-2 mb-2 articles">
                        <?php                 
                            while($posts = mysqli_fetch_assoc($responses)) {
                        ?>
                            <article class="col-md-4 mt-3 mb-3 article">
                                <a href="<?='./posts.php?p='.$posts['ID'] ?>" class="mt-0">
                                    <img src="<?=$posts['Banner'] ?>" style="width: 100%; height: 200px;" class="img-thumbnail border-0 mb-3"
                                        alt="<?=$posts['Title'] ?>" title="<?=$posts['Title'] ?>" />
                                    <h3 class="h3 article-title"><?=$posts['Title'] ?></h3>
                                    <p class="featured-muted"><?php 
                                        $summary = $posts['Summary'];
                                        $smyLen = strlen($summary);
                                        echo substr($summary,0,($smyLen<200)?$smyLen:300).'&hellip;';
                                    ?></p>
                                </a>
                                <div class="media">
                                    <img src="<?=$posts['Icon'] ?>" style="width: 40px; height: 40px;"
                                        class="img-thumbnail rounded-circle mr-3" alt="<?=$cgyPosts->AlterNateName($posts['Title']) ?>">
                                    <div class="media-body featured-muted">
                                        <h5 class="mt-0"><a href="<?='./authors.php?a='.str_replace(' ','',$posts['Author']) ?>"><?=$posts['Author'] ?></a></h5>
                                        <time><?=$cgyPosts->JustNowTiming($posts['Date']) ?></time> 
                                        <?=($posts['Type'] == 'Article') ? '&bull; '.$cgyPosts->ReadingTime($posts['Description']).' to read' : '' ?>
                                    </div>
                                </div>
                            </article>
                        <?php    
                            }
                        ?>
                    </section>
                    <?php    
                    }
                    else{
                    ?>
                    <section class="row jumbotron bg-info shadow">
                        <div class="col-md-12 text-dark">
                            <h3 class="h2 font-weight-light"><b class="font-weight-bold">Sorry!</b> the results may not found because of the following reasons:</h3>
                            <ul type="square">
                                <li class="font-weight-light">Seeking for activation</li>
                                <li class="font-weight-light">Moved permanently</li>
                                <li class="font-weight-light">Blocked/Removed by the member</li>
                            </ul>
                            <p class="font-weight-light">If not the reason, please contact the <b class="font-weight-bold">Learn from Developers Team</b>.</p>
                            <a href="./index.php" class="btn btn-lg btn-secondary">Go to Home <span class="fa fa-home"><span></a>
                        </div>
                    </section>
                    <?php    
                    }
                }
                else{
                   echo '<div class="lead"><h3>No results containing all your search terms were found.</h3> <p> Your search did not match any article(s)/video(s).</p> <ul><li>Make sure that all words are spelled correctly.</li><li>Try different keywords.</li><li>Try more general keywords.</li></ul></div>'; 
                }
            }
            else{
        ?>
        <section class="row mt-0 categorysection">
            <?php 
                $dataCategory = $categoryObj->Categories("");
                if (mysqli_num_rows($dataCategory) > 0) {
                    while($cagy = mysqli_fetch_assoc($dataCategory)) {
            ?>
                    <a href="<?='./categories.php?c='.$cagy['Category'] ?>" class="col-md-4 mt-3 mb-3 mr-0 categorylink">
                        <div class="media">
                        <img src="<?=$cagy['Icon'] ?>" style="width: 60px; height: 60px;" class="img-thumbnail mr-3" alt="<?=$cagy['Category'] ?>"/>
                            <div class="media-body featured-muted">
                                <h3 class="mt-0"><?=$cagy['Category'] ?></h3>
                                <span class="text-muted">
                                    <span id="acount">
                                        <?php 
                                            $countCgy = $categoryObj->CategoryCount('Article',$cagy['Category']);
                                            if(mysqli_num_rows($countCgy) > 0){
                                                while($ccnt = mysqli_fetch_assoc($countCgy)){
                                                    echo $ccnt['Articles'].' article(s)';
                                                }
                                            }
                                            else{
                                               echo '0 article(s)'; 
                                            }
                                        ?>
                                    </span>
                                    &bull;
                                    <span id="vcount">
                                        <?php 
                                            $countCgy2 = $categoryObj->CategoryCount('Video',$cagy['Category']);
                                            if(mysqli_num_rows($countCgy2) > 0){
                                                while($ccnt2 = mysqli_fetch_assoc($countCgy2)){
                                                    echo $ccnt2['Articles'].' video(s)';
                                                }
                                            }
                                            else{
                                               echo '0 video(s)'; 
                                            }
                                        ?>    
                                    </span>
                                </span>
                            </div>
                        </div>
                    </a>
            <?php                      
                    }
                } 
                else {
                    echo "Sorry! No Category added.";
                }
            ?>
        </section>
        <?php 
            }
        ?>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
    <script>
        Scroller('.categorysection','.categorylink',6);
    </script>
</body>

</html>
<?php 
    if(!isset($_SESSION)){
        session_start();
    }
    if(!empty($_GET['uoff'])){
        unset($_SESSION['laererg']);
        session_destroy();
        header('Location: index.php');
    }
?>
<noscript>
    <div class="alert alert-danger" role="alert">Please enable Javascript in your browser to avoid inconvenience.</div>
</noscript>
<section class="container mb-5">
        <nav class="navbar mainmenubar navbar-expand-lg fixed-top navbar-light bg-transparent">
            <a class="navbar-brand brandtxt mt-0 text-white" href="./index.php">
                <img src="./assets/learnfromdevelopers-logo.svg" width="35" height="35"
                    class="img-thumbnail rounded-0 mr-1" alt=""
                    style="background: transparent; border: transparent;" />
                Learn <em>from</em> <strong>Developers</strong>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mainmenu"
                aria-controls="mainmenu" aria-expanded="false" aria-label="Toggle navigation">
                <span class="fa fa-ellipsis-v text-white"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainmenu">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="./index.php">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Archives
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="./archives.php?year=2020">2020</a>
                            <a class="dropdown-item" href="./archives.php?year=2019">2019</a>
                            <a class="dropdown-item" href="./archives.php?year=2018">2018</a>
                            <a class="dropdown-item" href="./archives.php?year=2017">2017</a>
                            <a class="dropdown-item" href="./archives.php?year=2016">2016</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./categories.php">Categories</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./authors.php">Authors</a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0" name="search" action="search.php">
                    <input class="form-control mr-sm-2" name="q" id="q" size="50" type="search" placeholder="Search"
                        aria-label="Search" oninvalid="this.setCustomValidity('Please enter your keyword(s).');" oninput="this.setCustomValidity('');" required/>
                    <button class="btn btn-primary my-2 my-sm-0 mr-2" type="submit">
                        <span class="fa fa-search"></span>&nbsp;Search
                    </button>
                    <?php 
                        if(!empty($_SESSION['laererg'])){
                    ?>
                        <a class="btn btn-dark btn-sm mr-2" id="btn-dashboard" role="button" href="./dashboard.php"  data-toggle="tooltip" data-placement="bottom" title="Dashboard">
                           <span class="fa fa-cog"></span>
                        </a>
                        <a class="btn btn-info btn-sm mr-2" id="btn-contribute" role="button" href="./contribute.php"  data-toggle="tooltip" data-placement="bottom" title="Contribute">
                            Contribute<span class="fa fa-paper-plane ml-1"></span>
                        </a>
                        <a class="btn btn-danger btn-sm" id="btn-signout" role="button" href="?uoff=1"  data-toggle="tooltip" data-placement="bottom" title="Signout">
                            <span class="fa fa-sign-out mr-1"></span>Sign Out
                        </a>
                    <?php        
                        }
                        else{
                    ?>
                        <a class="btn btn-info btn-sm" role="button" href="./contribute.php">
                            Contribute<span class="fa fa-paper-plane ml-1"></span>
                        </a>
                    <?php        
                        }
                    ?>
                </form>
            </div>
        </nav>
</section>
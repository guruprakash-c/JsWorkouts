<script src="./assets/jquery.js"></script>
<script src="./assets/popper.js"></script>
<script src="./assets/bootstrap.js"></script>
<script src="./assets/scroll.js"></script>
<script src="./assets/notify.js"></script>
<script src="./assets/custom.js"></script>
<script src="./assets/datatable.js"></script>
<script src="./assets/bootstrap-datatable.js"></script>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
$('input.imgurl').change(function(){
    var fileUrl = $(this).val();
    if(fileUrl.match(/\.(jpeg|jpg|svg|png)$/) == null){
        $(this).val('');
    }
    else{
        $(this).val(fileUrl);
    }  
});
$('button.js-gotop').click(function (e) {
    e.preventDefault();
    $('body,html').animate({
        scrollTop: 0
    }, 1000);
    return false;
});
$('.tox-notifications-container').css({'display':'none !important'});
$(document).ready(function(){
    $('.dtlstbl').DataTable(
        {
            pageLength: 10
        }
    );
});
$('#showpwd').on('change',function(){
    if($(this).is(":checked")){
        $('#pwdlbl').text('Hide Password');
        $('#newpassword,#repassword,#userpswd').attr('type','text');   
    }
    else{
        $('#pwdlbl').text('Show Password');
        $('#newpassword,#repassword,#userpswd').attr('type','password');   
    }
});
function validatePassword(pwd){
  debugger;
  var r = false;
  
  if(pwd.value != undefined && pwd.value != ''){
    var attr = $('#'+pwd.id).attr('aria-describedby');
    $('#'+attr).removeClass('bg-success text-white');
    $('#'+attr).removeClass('bg-danger text-white');
    var helpText = $('#'+attr).text();
    var re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,12}$/;
    if(re.test(pwd.value) == false){
      pwd.focus();
      if(attr != undefined && attr != '') $('#'+attr).addClass('bg-danger text-white');
      pwd.value = '';
      r = false;
    }
    else{
      r = true;
      if(attr != undefined && attr != '') $('#'+attr).addClass('bg-success text-white');
    }
  }
  return r;
}
</script>
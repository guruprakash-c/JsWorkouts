<script>
function myFunction() {
  var copyText = document.getElementById("input");
  copyText.select();
  copyText.setSelectionRange(0, 99999);
  document.execCommand("copy");
  document.getElementById("btn").innerHTML = "copied to clipboard";
  document.getElementById("btn").disabled = true;
  setInterval(function(){
    document.getElementById("btn").disabled = false;
    document.getElementById("btn").innerHTML = "Copy";
  },2000);   
} 
</script>
<input id="input" value="Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore reiciendis soluta commodi officia ducimus at deleniti perferendis dolorem excepturi. Ipsam error corrupti nihil est eligendi veritatis inventore, repudiandae ducimus! Modi."/>
<button type="button" id="btn" onclick="myFunction()">Copy</button>
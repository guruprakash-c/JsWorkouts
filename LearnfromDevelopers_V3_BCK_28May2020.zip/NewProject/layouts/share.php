<div class="modal fade" data-backdrop="static" id="sharemdl" tabindex="-1" role="dialog" aria-labelledby="sharemdlLbl" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="sharemdlLbl">Share this page:</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" data-toggle="tooltip" data-placement="top" title="Click here to close this dialog.">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Share icons
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>
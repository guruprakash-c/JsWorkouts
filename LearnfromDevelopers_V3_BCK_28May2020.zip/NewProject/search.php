<?php 
    //error_reporting(0);
    require_once "./controller/Posts.php";
    require_once "./controller/Miscellaneous.php";
    $misc = new Miscellaneous();
    $misc->Consent();

    $qury = new Posts();
    $responses = null;
    if(!empty($_GET['q'])){
        $responses = $qury->GetSearch($_GET['q'],"","");
    }
    else if(!empty($_GET['c'])){
        $responses = $qury->GetSearch("",$_GET['c'],"");
    }
    else if(!empty($_GET['a'])){
        $responses = $qury->GetSearch("","",$_GET['a']);
    }
    else{
        $responses = null;
    }
     
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Searching &ndash; Learn from Developers</title>
    <?php require_once "./layouts/head.php"; ?>
</head>
<body>
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <main class="container mt-4 search-body" style="margin-top: 7em !important;">
        <?php 
        if($responses != null){
            if (mysqli_num_rows($responses) > 0) {
                echo '<p class="lead">about <em class="font-weight-bold">'.mysqli_num_rows($responses).'</em> article(s)</p>';
            ?>
            <section class="row mt-0 articles">
                <?php                 
                    while($posts = mysqli_fetch_assoc($responses)) {
                ?>
                    <article class="col-md-4 mt-3 mb-3 article">
                        <a href="<?='./posts.php?p='.$posts['ID'] ?>" class="mt-0">
                            <img src="<?=$posts['Banner'] ?>" style="width: 100%; height: 200px;" class="img-thumbnail border-0 mb-3"
                                alt="<?=$posts['Title'] ?>" title="<?=$posts['Title'] ?>" />
                            <h3 class="h3 article-title"><?=$posts['Title'] ?></h3>
                            <p class="featured-muted"><?php 
                                $summary = $posts['Summary'];
                                $smyLen = strlen($summary);
                                echo substr($summary,0,($smyLen<200)?$smyLen:300).'&hellip;';
                            ?></p>
                        </a>
                        <div class="media">
                            <img src="<?=$posts['Icon'] ?>" style="width: 40px; height: 40px;"
                                class="img-thumbnail rounded-circle mr-3" alt="<?=$qury->AlterNateName($posts['Title']) ?>">
                            <div class="media-body featured-muted">
                                <h5 class="mt-0"><a href="<?='./search.php?a='.str_replace(' ','',$posts['Author']) ?>"><?=$posts['Author'] ?></a></h5>
                                <time><?=$qury->JustNowTiming($posts['Date']) ?></time> 
                                <?=($posts['Type'] == 'Article') ? '&bull; '.$qury->ReadingTime($posts['Description']).' to read' : '' ?>
                            </div>
                        </div>
                    </article>
                    <?php    
                    }
                ?>
            </section>
            <?php 
            }
            else{
                echo '<div class="lead"><h3>No results containing all your search terms were found.</h3> <p> Your search did not match any article(s)/video(s).</p> <ul><li>Make sure that all words are spelled correctly.</li><li>Try different keywords.</li><li>Try more general keywords.</li></ul></div>';
            }
            ?>
            
        <?php 
        }
        else{
            echo '<p class="lead">No results containing all your search terms were found. <br/> Your search did not match any article(s)/video(s).<br/> <ul><li>Make sure that all words are spelled correctly.</li><li>Try different keywords.</li><li>Try more general keywords.</li></ul></p>';
        }
        ?>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
    <script>
        Scroller('.articles','.article',3);
    </script>
</body>
</html>
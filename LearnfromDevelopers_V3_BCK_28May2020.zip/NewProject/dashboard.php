<?php 
//error_reporting(0);
require_once "./controller/Subscriber.php";
require_once "./controller/Category.php";
require_once "./controller/Posts.php";
require_once "./controller/Miscellaneous.php";

session_start();

$misc = new Miscellaneous();
$misc->Consent();
$currUsr = '';

if(empty($_SESSION['laererg'])){
    header('Location: contribute.php');   
}else{
    $currUsr = $_SESSION['laererg'];
}

$categoryObj = new Category();
$cgyPosts = new Posts();
$userProfObj = new Subscriber();

$logUsr = explode('@',$currUsr)[0];
if(!empty($_GET['uoff'])){
    unset($_SESSION['laererg']);
    session_destroy();
    header('Location: index.php');
}
$status = '';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Dashboard &mdash; Learn from Developers</title>
    <?php require_once "./layouts/head.php"; ?>
    <style>
    .tabpage .nav-link {
        color: #020202;
        background: #DFD7CA;
        border-left: 3px solid #DFD7CA !important;
        border-radius: 0px;
    }

    .tabpage .nav-link.active {
        border-left: 3px solid #1976d2 !important;
        color: #1972d6;
    }
    </style>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
</head>

<body>
    <header class="clearfix">
        <section class="float-left">
            <a class="navbar-brand brandtxt mt-0 text-white" href="./index.php">
                <img src="./assets/learnfromdevelopers-logo.svg" width="35" height="35"
                    class="img-thumbnail rounded-0 mr-1" alt="" style="background: transparent; border: transparent;" />
                Learn <em>from</em> <strong>Developers</strong>
            </a>
        </section>
        <section class="float-right text-white">
            <?='Welcome '.$logUsr ?>
            <a class="btn btn-info btn-sm" id="btn-signout" role="button" href="./contribute.php" data-toggle="tooltip"
                data-placement="bottom" title="Contribute">
                <span class="fa fa-paper-plane mr-1"></span>Contribute
            </a>
            <a class="btn btn-danger btn-sm" id="btn-signout" role="button" href="?uoff=1" data-toggle="tooltip"
                data-placement="bottom" title="Signout">
                <span class="fa fa-sign-out mr-1"></span>Sign Out
            </a>
        </section>
    </header>
    <main class="container mt-3" style="">
        <div class="row">
            <div class="col-md-3">
                <div class="nav flex-column nav-pills tabpage" id="v-pills-tab" role="tablist"
                    aria-orientation="vertical">
                    <a class="nav-link" id="v-pills-posts-tab" data-toggle="pill" href="#v-pills-posts"
                        role="tab" aria-controls="v-pills-posts" aria-selected="false">
                        <span class="fa fa-files-o mr-1"></span>Posts
                    </a>
                    <a class="nav-link" id="v-pills-categories-tab" data-toggle="pill" href="#v-pills-categories"
                        role="tab" aria-controls="v-pills-categories" aria-selected="false">
                        <span class="fa fa-tags mr-1"></span>Categories
                    </a>
                    <a class="nav-link" id="v-pills-authors-tab" data-toggle="pill" href="#v-pills-authors" role="tab"
                        aria-controls="v-pills-authors" aria-selected="false">
                        <span class="fa fa-user mr-1"></span>Authors
                    </a>
                    <a class="nav-link active" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab"
                        aria-controls="v-pills-settings" aria-selected="true">
                        <span class="fa fa-empire mr-1"></span>Settings
                    </a>
                </div>
            </div>
            <div class="col-md-9">
                <?php 
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        if(!empty($_POST['currusername']) &&
                        !empty($_POST['currpasssword']) &&
                        !empty($_POST['newpassword']) && 
                        !empty($_POST['repassword'])){
                            if($_POST['currpasssword'] != $_POST['newpassword']){
                                if($_POST['newpassword'] == $_POST['repassword']){
                                    $profile = array(
                                                    'uname' => $_POST['currusername'],
                                                    'usrpsswd' => $_POST['currpasssword'],
                                                    'nwpsswd' => $_POST['newpassword'],
                                                    'rpsswd' => $_POST['repassword'] 
                                            );
                                    $response = $userProfObj->UpdateUser($profile);
                                    if($response) {
                                        $resp2 = explode('|', $response)[1]; 
                                        switch ($resp2) {
                                            case -1:
                                                echo '<div class="alert alert-warning alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> Invalid current password.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                                header('refresh:5;url=dashboard.php?uoff=1');
                                                break;
                                            case 0:
                                                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> Something went wrong.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                                break;
                                            case 1:
                                                echo '<div class="alert alert-success alert-dismissible fade show" role="alert"> <strong>Congratulations!</strong>Your profile is updated.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                                header('refresh:5;url=dashboard.php?uoff=1');
                                                break;
                                        }
                                    }
                                }
                                else{
                                    echo '<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong>Warning!</strong> Your password mis-matches<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>'; 
                                }
                            }
                            else{
                                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"><strong>Error!</strong> Entered password resembles your current password, so please enter a different password.<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
                            }
                        }
                    }
                ?>
                <div class="tab-content" id="v-pills-tabContent">
                    <div class="tab-pane fade" id="v-pills-posts" role="tabpanel"
                        aria-labelledby="v-pills-posts-tab">
                        <!--section class="maparea container-fluid shadow-sm px-2 py-2">
                            <section class="row">
                                <div class="col-md-12">
                                    <div id="articlechart" style="width: 100%; height: 500px;"></div>
                                    <script type="text/javascript">
                                        google.load("visualization", "1", {packages:["corechart"]});
                                        google.setOnLoadCallback(drawChart);
                                        function drawChart() {
                                        var data = google.visualization.arrayToDataTable([
                                        ['Article', 'Visits'],
                                        ['flow data using inkscape',0],
                                        ['Photoshop',80],
                                        ['C#',200],
                                        ['ASP.NET',220],
                                        ['Unity',280],
                                        ['C#',210],
                                        ['flow data using inkscape',100],
                                        ['Photoshop',80],
                                        ['C#',210],
                                        ['flow data using inkscape',300],
                                        ]);

                                        var options = {
                                        title: 'Date wise visits'
                                        };
                                        var chart = new google.visualization.AreaChart(document.getElementById("articlechart"));
                                        chart.draw(data, options);
                                        }
                                    </script>
                                </div>
                                <div class="col-md-12 mt-2"></div>
                            </section>
                        </section-->
                        <section class="articlearea responsive-table px-2 py-2">
                            <table class="table table-bordered dtlstbl">
                                <thead class="bg-info-light">
                                    <tr>
                                        <th>Post Title</th>
                                        <th>Category</th>
                                        <th>Author</th>
                                        <th>Status</th>
                                        <th>
                                            Actions
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="bg-info-light">
                                            Digital Trends
                                        </td>
                                        <td>Science</td>
                                        <td>Mosh Hamedani</td>
                                        <td>
                                            <?php 
                                                $status = 1;
                                                switch($status){
                                                    case 0:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="Inactive" class="fa fa-times-circle text-danger fa-2x"></span>'; 
                                                    break;
                                                    case 1:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="Active" class="fa fa-check-circle text-success fa-2x"></span>'; 
                                                    break;
                                                    default:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="on-Hold" class="fa fa-exclamation-circle text-warning fa-2x"></span>'; 
                                                    break;
                                                }
                                            ?>
                                        </td>
                                        <td>
                                            <small class="mt-1 mb-1 text-sm">
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    View Details
                                                </a>/
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    Edit
                                                </a>/
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    Block
                                                </a>
                                            </small>        
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-info-light">TechSpot</td>
                                        <td>Technology</td>
                                        <td>KudVenkat</td>
                                        <td>
                                            <?php 
                                                $status = 1;
                                                switch($status){
                                                    case 0:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="Inactive" class="fa fa-times-circle text-danger fa-2x"></span>'; 
                                                    break;
                                                    case 1:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="Active" class="fa fa-check-circle text-success fa-2x"></span>'; 
                                                    break;
                                                    default:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="on-Hold" class="fa fa-exclamation-circle text-warning fa-2x"></span>'; 
                                                    break;
                                                }
                                            ?>  
                                        </td>
                                        <td>
                                            <small class="mt-1 mb-1 text-sm">
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    View Details
                                                </a>/
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    Edit
                                                </a>/
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    Block
                                                </a>
                                            </small>        
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-info-light">Health</td>
                                        <td>Health &amp; Fitness</td>
                                        <td>Paul Seal</td>
                                        <td>
                                            <?php 
                                                $status = 0;
                                                switch($status){
                                                    case 0:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="Inactive" class="fa fa-times-circle text-danger fa-2x"></span>'; 
                                                    break;
                                                    case 1:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="Active" class="fa fa-check-circle text-success fa-2x"></span>'; 
                                                    break;
                                                    default:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="on-Hold" class="fa fa-exclamation-circle text-warning fa-2x"></span>'; 
                                                    break;
                                                }
                                            ?>
                                        </td>
                                        <td>
                                            <small class="mt-1 mb-1 text-sm">
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    View Details
                                                </a>/
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    Edit
                                                </a>/
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    Block
                                                </a>
                                            </small>        
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-info-light">Gameloft</td>
                                        <td>Gaming</td>
                                        <td>Dan Vas</td>
                                        <td>
                                            <?php 
                                                $status = 3;
                                                switch($status){
                                                    case 0:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="Inactive" class="fa fa-times-circle text-danger fa-2x"></span>'; 
                                                    break;
                                                    case 1:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="Active" class="fa fa-check-circle text-success fa-2x"></span>'; 
                                                    break;
                                                    default:
                                                        echo '<span data-toggle="tooltip" data-placement="top" title="on-Hold" class="fa fa-exclamation-circle text-warning fa-2x"></span>'; 
                                                    break;
                                                }
                                            ?>        
                                        </td>
                                        <td>
                                            <small class="mt-1 mb-1 text-sm">
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    View Details
                                                </a>/
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    Edit
                                                </a>/
                                                <a href="?v=s9dfsdf" target="_blank">
                                                    Block
                                                </a>
                                            </small>        
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot></tfoot>
                            </table>
                        </section>
                    </div>
                    <div class="tab-pane fade" id="v-pills-categories" role="tabpanel"
                        aria-labelledby="v-pills-categories-tab">
                        <section class="maparea shadow-sm px-2 py-2">
                            Google Chart
                        </section>
                        <section class="articlearea responsive-table px-2 py-2">
                            <table class="table table-bordered dtlstbl1">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Feed Title</th>
                                        <th>Category</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><a href="#" target="_blank">DigitalTrends</a></td>
                                        <td>Science</td>
                                        <td>Active</td>
                                    </tr>
                                    <tr>
                                        <td><a href="#" target="_blank">TechSpot</a></td>
                                        <td>Technology</td>
                                        <td>Active</td>
                                    </tr>
                                    <tr>
                                        <td><a href="#" target="_blank">Health</a></td>
                                        <td>Health &amp; Fitness</td>
                                        <td>InActive</td>
                                    </tr>
                                    <tr>
                                        <td><a href="#" target="_blank">Gameloft</a></td>
                                        <td>Gaming</td>
                                        <td>Active</td>
                                    </tr>
                                </tbody>
                                <tfoot></tfoot>
                            </table>
                        </section>
                    </div>
                    <div class="tab-pane fade" id="v-pills-authors" role="tabpanel"
                        aria-labelledby="v-pills-authors-tab">
                        <section class="maparea shadow-sm px-2 py-2">
                            Google Chart
                        </section>
                        <section class="articlearea responsive-table px-2 py-2">
                            <table class="table table-bordered dtlstbl2">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Feed Title</th>
                                        <th>Category</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><a href="#" target="_blank">DigitalTrends</a></td>
                                        <td>Science</td>
                                        <td>Active</td>
                                    </tr>
                                    <tr>
                                        <td><a href="#" target="_blank">TechSpot</a></td>
                                        <td>Technology</td>
                                        <td>Active</td>
                                    </tr>
                                    <tr>
                                        <td><a href="#" target="_blank">Health</a></td>
                                        <td>Health &amp; Fitness</td>
                                        <td>InActive</td>
                                    </tr>
                                    <tr>
                                        <td><a href="#" target="_blank">Gameloft</a></td>
                                        <td>Gaming</td>
                                        <td>Active</td>
                                    </tr>
                                </tbody>
                                <tfoot></tfoot>
                            </table>
                        </section>
                    </div>
                    <div class="tab-pane fade show active" id="v-pills-settings" role="tabpanel"
                        aria-labelledby="v-pills-settings-tab">
                        <form name="changepwd" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="currusername">Username</label>
                                <input type="text" class="form-control" name="currusername" id="currusername" aria-describedby="unameHelp"
                                    value="<?=$currUsr ?>" readonly/>
                                <small id="unameHelp" class="form-text text-muted">your registered email address</small>
                            </div>
                            <div class="form-group">
                                <label for="currpasssword">Current Password</label>
                                <input type="password" class="form-control" name="currpasssword" id="currpasssword" value="tesT@1234567"/>
                            </div>
                            <div class="form-group">
                                <label for="newpassword">New Password</label>
                                <input type="password" class="form-control" name="newpassword" id="newpassword"
                                    aria-describedby="npwdHelp" onchange="validatePassword(this);"/>
                                <small id="npwdHelp" class="form-text px-2 py-2">
                                    Your password must be:
                                    <ul>
                                        <li> 8 to 12 characters.</li>
                                        <li> at least 1 uppercase letter</li>
                                        <li> at least 1 lowercase letter</li>
                                        <li> at least 1 number</li>
                                        <li> at least 1 these @,$,!,%,*,?,& special character</li>
                                    </ul>
                                </small>
                            </div>
                            <div class="form-group">
                                <label for="repassword">Re-enter Password</label>
                                <input type="password" class="form-control" name="repassword" id="repassword"
                                    aria-describedby="rnnpwdHelp" onchange="validatePassword(this);"/>
                                <small id="rnpwdHelp" class="form-text text-muted">
                                    please re-enter the password.
                                </small>
                            </div>
                            <div class="form-group form-check">
                                <input type="checkbox" class="form-check-input" id="showpwd">
                                <label class="form-check-label" id="pwdlbl" for="showpwd">Show Password</label>
                            </div>
                            <button type="submit" class="btn btn-primary">Update Password</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer class="container-fluid py-5">

    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
    <script>
    Scroller('.categorysection', '.categorylink', 6);
    </script>
</body>

</html>
<?php
ini_set('expose_php','off');
ini_set('error_reporting',E_ALL);

ob_start();

require_once "./controller/Posts.php";
require_once "./controller/Category.php";
require_once "./controller/Author.php";

$postUri = $category = $author = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $operator = new Operations();
    if(!empty($_POST['url']) && empty($_POST['category']) && empty($_POST['author'])){
        echo $operator->CheckExisted(1,$_POST['url'],"","");
    }
    else if(empty($_POST['url']) && !empty($_POST['category']) && empty($_POST['author'])){
        echo $operator->CheckExisted(2,'',$_POST['category'],"");
    }
    else if(empty($_POST['url']) && empty($_POST['category']) && !empty($_POST['author'])){
        echo $operator->CheckExisted(3,'','',$_POST['author']);
    }
    else{
        $response = array(
            'message'=>'',
            'exits'=>0,
        );
        header(json_encode($response),true,http_response_code(404));
    }
}
else{
    $response = array(
        'message'=>'',
        'exists'=>0
    );
    header(json_encode($response),true,http_response_code(404));
}

final class Operations{ 
    private $response = array();
    function CheckExisted($options,$postUrl="",$category="",$author=""){
        $output = array(); 
        if(!empty($options)){
            switch ($options) {
                case 1:
                    # Check Post
                    $output = $this->CheckPost($uri);
                    break;
                case 2:
                    # Check Category
                    $output = $this->CheckCategory($category);
                    break;
                case 3:
                    # Check Author
                    $output = $this->CheckAuthor($author);
                    break;
            }
            $this->response = $output;
        }
        return $this->response;
    }
    private function CheckPost($uri){
        $output = array();
        try{
            if(!empty($uri)){
                echo '<script>alert("'.$uri.'");</script>';
                $chkPost = new Posts();
                $data = $chkPost->CheckPost($uri);
                if($data == true){
                    $output = array(
                        'message'=>'Exists',
                        'exists'=>1
                    );
                }
                else{
                    $output = array(
                        'message'=>'Not Exists',
                        'exists'=>0
                    );
                }
            }
            else{
                $output = array(
                    'message'=>'',
                    'exits'=>-1
                );
            }
            header(json_encode($output),true,http_response_code(200));
            header('Content-Type: application/json');    
        }
        catch(Exception $ex){
            $output = array(
                'exists'=>-2
            );
            header(json_encode($output),true,http_response_code(500));
        }
        return $output;
    } 
    private function CheckAuthor($author){
        $output = array();
        try{
            if(!empty($author)){
                $chkAuthr = new Posts();
                $data = $chkAuthr->CheckPost($author);
                if($data == true){
                    $output = array(
                        'message'=>'Exits',
                        'exists'=>1
                    );
                }
                else{
                    $output = array(
                        'message'=>'Not Exits',
                        'exists'=>0
                    );
                }
            }
            else{
                $output = array(
                    'message'=>'',
                    'exists'=>-1
                );
            }
            header(json_encode($output),true,http_response_code(200));
            header('Content-Type: application/json');    
        }
        catch(Exception $ex){
            $output = array(
                'message'=>'',
                'exists'=>-2
            );
            header(json_encode($output),true,http_response_code(500));
        }
        return $output;
    }
    private function CheckCategory($category){
        $output = array();
        try{
            if(!empty($category)){
                $chkCagy = new Posts();
                $data = $chkCagy->CheckPost($category);
                if($data == true){
                    $output = array(
                        'message'=>'Exists',
                        'exists'=>1
                    );
                }
                else{
                    $output = array(
                        'message'=>'Not Exists',
                        'exists'=>0
                    );
                }
            }
            else{
                $output = array(
                    'message'=>'',
                    'exists'=>-1
                );
            }
            header(json_encode($output),true,http_response_code(200));
            header('Content-Type: application/json');    
        }
        catch(Exception $ex){
            $output = array(
                'message'=>'',
                'exists'=>-2
            );
            header(json_encode($output),true,http_response_code(500));
        }
        return $output;
    }
}
<?php
    //error_reporting(0);
    if(!isset($_SESSION)){
        session_start();
    }
    require_once "./controller/Posts.php";
    require_once "./controller/Miscellaneous.php";
    require_once "./controller/Subscriber.php";
    require_once "./controller/Views.php";

    $pgVws = new Views();

    $misc = new Miscellaneous();
    $misc->Consent();    

    $currUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $blogPosts = array();
    $noPost = false;
    $postObj = new Posts();
    $vws = 0;
    if(!empty($_GET['p'])){
        $postId = $_GET['p'];
        $postArticle = $postObj->GetPosts($postId);    
        $userIp = $pgVws->FetchIP();
        $pvw = $pgVws->UserViews($postId,$userIp);
        $_SESSION['uView'] = trim($userIp);
        $vws = ''; 
        if($pvw != null){
            if(mysqli_num_rows($pvw)>0){
                while($vPg = mysqli_fetch_assoc($pvw)){
                    $vws = $vPg['Views']; 
                }
            }
        }
        $pgVws->AddViews($postId,$userIp);
        if(mysqli_num_rows($postArticle)>0){
            $noPost = true;
            while($rData = mysqli_fetch_assoc($postArticle)){
                $blogPosts = array(
                    'ID'=>$rData['ID'],
                    'Date'=>$rData['Date'],
                    'Title'=>htmlspecialchars_decode($rData['Title']),
                    'AID'=>$rData['AuthorId'],
                    'Author'=>$rData['Author'],
                    'Bio'=>$rData['Bio'],
                    'Photo'=>$rData['AuthorPhoto'],
                    'FaceBook'=>$rData['Facebook'],
                    'Twitter'=>$rData['Twitter'],
                    'WebSite'=>$rData['Website'],
                    'CID'=>$rData['CategoryId'],
                    'Category'=>$rData['Category'],
                    'Icon'=>$rData['Icon'],
                    'Poster'=>$rData['CategoryPoster'],
                    'Summary'=>htmlspecialchars_decode($rData['Summary']),
                    'Type'=>$rData['Type'],
                    'Description'=>htmlspecialchars_decode($rData['Description']),
                    'Tags'=>htmlspecialchars_decode($rData['Keywords']),
                    'Banner'=>$rData['Banner'],
                    'Source'=>$rData['Source'],
                    'Featured'=>$rData['Featured'],
                    'Views'=>$vws,//$rData['Views'],
                    'Status'=>$rData['PostStatus']
                );
            }
        }
        else{
            $noPost = false;
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once "./layouts/head.php"; ?>
    <title><?=$blogPosts['Title'] ?> by <?=$blogPosts['Author'] ?> <?=($vws>0) ? '&ndash; '.$vws.' users viewed' : '' ?> &mdash; Learn from Developers</title>
    <meta name="description" content="<?=$blogPosts['Summary'] ?>" />
    <meta name="keywords" content="<?=$blogPosts['Tags'] ?>" />
    <meta name="author" content="L&aelig;rer Labs" />
    <!-- Facebook and Twitter integration -->
    <meta property="og:title" content="<?=$blogPosts['Title'] ?>" />
    <meta property="og:image" content="<?=$blogPosts['Banner'] ?>" />
    <meta property="og:url" content="<?=$currUrl ?>" />
    <meta property="og:site_name" content="Learn from Developers" />
    <meta property="og:description" content="<?=$blogPosts['Summary'] ?>" />
    <meta name="twitter:title" content="<?=$blogPosts['Title'].' - Learn from Developers' ?>" />
    <meta name="twitter:image" content="<?=$blogPosts['Banner'] ?>" />
    <meta name="twitter:url" content="<?=$currUrl ?>" />
    <meta name="twitter:card" content="" />
    <link rel="canonical" href="<?=$currUrl ?>" />
</head>
<body>
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <section class="container-fluid">
        <?php 
            if($noPost){
        ?>
        <article class="row">
            <figure class="col-md-12 figure">
                <img src="<?=$blogPosts['Banner'] ?>" style="height: 580px; width: 100%" class="figure-img img-fluid border-0 mb-3" alt="<?=$blogPosts['Title'] ?>" title="<?=$blogPosts['Title'] ?>" />
            </figure>
        </article>
        <?php 
            }
        ?>
    </section>
    <main class="container mt-4 article-body" style="margin-top: 3em !important;">
        <?php 
            if(!empty($_POST['uName']) && !empty($_POST['uEmail'])){
                $subscriber = array(
                    'userName'=>$_POST['uName'],
                    'userEmail'=>$_POST['uEmail']
                );
                $sub = new Subscriber();
                $response = $sub->Subscription($subscriber);
                switch ($response) {
                    case -2:
                        $_SESSION['cnx'] = $_POST['uName'];     
                        break;
                    case 3:
                        $_SESSION['cnx'] = '';     
                        $_SESSION['laererg'] = $_POST['uName'];
                        break;
                    case -1:
                        $_SESSION['cnx'] = $_POST['uName'];     
                        break;
                    case 1:
                        $_SESSION['cnx'] = $_POST['uName'];     
                        break;
                    case 0:
                        $_SESSION['cnx'] = '';     
                        break;
                }
            }
        ?>
        <?php 
            if($noPost){
        ?>
        <section class="row">
            <article class="col-md-10 mt-3 mb-3 mx-auto">
                <h3 class="h1 article-title"><?=$blogPosts['Title'] ?></h3>
                <div class="media">
                    <img src="<?=$blogPosts['Icon'] ?>" style="width: 40px; height: 40px;" class="img-thumbnail rounded-circle mr-3" alt="<?=$postObj->AlterNateName($blogPosts['Category']) ?>" title="<?=$blogPosts['Category'] ?>"/>
                    <div class="media-body featured-muted">
                        <h5 class="mt-0 mb-0">
                            <a href="<?='./categories.php?c='.$blogPosts['CID'] ?>">
                                <?=$blogPosts['Category'] ?>
                            </a>
                        </h5>
                        <span class="mt-0">
                            <time>
                                <?=$postObj->JustNowTiming($blogPosts['Date']) ?>
                            </time> 
                            <?=($blogPosts['Type'] == 'Article') ? '&bull; '.$postObj->ReadingTime($blogPosts['Description']).' to read' : '' ?>
                            <?php 
                                if($blogPosts['Views'] > 0){
                                    $uViews = $blogPosts['Views'];
                                    if($uViews>1000){
                                        $uViews = '&bull; '.round($uViews/1000).'K views';
                                    }
                                    else{
                                        $uViews = '&bull; '.$uViews.' views';
                                    }
                                    echo $uViews;
                                }
                            ?>
                        </span>
                    </div>
                    <div>
                        <a href="<?='https://twitter.com/intent/tweet?url='.$currUrl.'&text='.$blogPosts['Title'].' by '.$blogPosts['Author'].' - Learn from Developers&via=guruprakashc&hashtags='.$blogPosts['Tags'] ?>" rel="external" class="text-dark mr-2" target="_blank">
                            <span class="fa fa-twitter"></span>
                        </a>
                        <a href="<?='https://www.facebook.com/sharer.php?u='.$currUrl ?>" rel="external" class="text-dark mr-2" target="_blank">
                            <span class="fa fa-facebook"></span>
                        </a>
                        <a href="<?='http://pinterest.com/pin/create/link/?url='.$currUrl ?>" rel="external" class="text-dark mr-2" target="_blank">
                            <span class="fa fa-pinterest"></span>
                        </a>
                        <a href="<?='whatsapp://send?text='.$currUrl ?>" rel="external" class="text-dark mr-2" target="_blank">
                            <span class="fa fa-whatsapp"></span>
                        </a>
                        <a href="javascript:void(0)" class="text-dark mr-2" rel="bookmark"
                            onclick="javascript: alert('Press CTRL + D to bookmark this <?=$blogPosts['Type'] ?> ');" style="cursor: pointer;">
                            <span class="fa fa-bookmark-o"></span>
                        </a>
                        <a href="javascript:void(0)" data-toggle="modal" data-target="#sharemdl" title="Click to get more options" class="badge badge-dark mr-2" style="cursor: pointer;" >
                            <span class="fa fa-ellipsis-h"></span>
                        </a>
                    </div>
                </div>
                <div class="mt-3 article-body">
                    <?php
                        if($blogPosts['Type'] == 'Video'){
                            echo '<div class="embed-responsive embed-responsive-16by9"><iframe class="embed-responsive-item" src="'.$blogPosts['Description'].'" allowfullscreen></iframe></div>';
                        }
                        else if($blogPosts['Type'] == 'Article'){
                            echo $blogPosts['Description'];
                        }
                    ?>
                </div>
                <?php 
                    if((!empty($_SESSION['cnx']) || !empty($_SESSION['laererg'])) && $blogPosts['Type'] != 'Video'){
                ?>
                    <div class="mt-1 article-body text-right">
                            <?php 
                                $tgs = explode(',',$blogPosts['Tags']);
                                $tgSize = sizeof($tgs);
                                $tg = explode(',',$blogPosts['Tags'])[0];
                                $genUri = '?utm_source=learnfromdevelopers&utm_medium=cpc&utm_campaign=promolyncs&utm_term='.$tg.'&utm_content=promolyncs';
                                $fmtUri = $blogPosts['Source'].$genUri; 
                            ?>
                        <a href="<?=$fmtUri ?>" target="_blank" class="btn btn-primary btn-lg" role="button">
                            Read more <span class="fa fa-chevron-circle-right"></span>
                        </a>
                    </div>
                <?php } ?>
                <section class="mt-3">
                    <?php 
                        $tags = explode(',',$blogPosts['Tags']);
                        foreach($tags as $tag){
                            echo '<a href="./search.php?q='.trim($tag).'" class="badge bg-default mr-1" rel="tag">'.$tag.'</a>';
                        } 
                    ?>
                </section>
                <section class="media mt-3 py-3 border px-2 lead bg-white">
                    <img src="<?=$blogPosts['Photo'] ?>" style="width: 100px; height: 100px;" class="img-thumbnail mr-3" alt="<?=$postObj->AlterNateName($blogPosts['Author']) ?>" title="<?=$blogPosts['Author'] ?>">
                    <div class="media-body featured-muted">
                        <h5 class="mt-0 mb-0">
                            <a href="<?='./search.php?a='.str_replace(' ','',$blogPosts['Author']) ?>">
                                <?=$blogPosts['Author'] ?>
                            </a>
                        </h5>
                        <span class="mt-0">
                            <?php 
                                if(!empty($blogPosts['FaceBook'])){
                                    echo '<a href="'.$blogPosts['FaceBook'].'" rel="external" class="text-dark mr-2" target="_blank"><span class="fa fa-facebook-official"></span></a>';
                                }

                                if(!empty($blogPosts['Twitter'])){
                                    echo '<a href="'.$blogPosts['Twitter'].'" rel="external" class="text-dark mr-2" target="_blank"><span class="fa fa-twitter-square"></span></a>';
                                }
                            ?>
                        </span>
                        <p>
                            <?=trim(substr($blogPosts['Bio'],0,300).'&hellip;') ?>
                            <?=(!empty($blogPosts['WebSite']) ? '<a href="'.$blogPosts['WebSite'].'" rel="external" target="_blank">read more &raquo;</a>' : '') ?>
                        </p>
                    </div>
                </section>
            </article>
        </section>

        <section class="row mt-3">
            <?php 
                $relatedPosts = $postObj->GetRelatedPosts($postId,$blogPosts['CID']);
                if(mysqli_num_rows($relatedPosts)>0){
                   while($rData = mysqli_fetch_assoc($relatedPosts)){
            ?>
                        <article class="col-md-4 mt-3 mb-3">
                            <a href="<?='./posts.php?p='.$rData['ID'] ?>" class="mt-0">
                                <img src="<?=$rData['Banner'] ?>" style="width: 100%; height: 200px;" class="img-thumbnail border-0 mb-3" alt="<?=$rData['Title'] ?>" title="<?=$rData['Title'] ?>" />
                                <h3 class="h3 article-title"><?=$rData['Title'] ?></h3>
                                <p class="featured-muted">
                                    <?php 
                                        $relatedSummary = $rData['Summary'];
                                        $relatedSize = strlen($relatedSummary);
                                        echo substr($relatedSummary,0,($relatedSize < 200) ? $relatedSize : 200).'&hellip;';
                                    ?>
                                </p>
                            </a>
                            <div class="media"> 
                                <img src="<?=$rData['AuthorPhoto'] ?>" style="width: 40px; height: 40px;" class="img-thumbnail rounded-circle mr-3 h4 font-weight-bold text-center bg-light" alt="<?=$postObj->AlterNateName($rData['Author']) ?>" title="<?=$rData['Author'] ?>"/>
                                <div class="media-body featured-muted">
                                    <h5 class="mt-0"><a href="<?='./search.php?a='.str_replace(' ','',$rData['Author']) ?>"><?=$rData['Author'] ?></a></h5>
                                    <time><?=$postObj->JustNowTiming($rData['Date']) ?></time> <?=($blogPosts['Type'] == 'Article') ? '&bull; '.$postObj->ReadingTime($blogPosts['Description']).' to read' : '' ?>
                                </div>
                            </div>
                        </article>
            <?php           
                   } 
                }
            ?>
        </section>                        
        <?php 
            }
            else{
        ?>
        <section class="row jumbotron shadow">
            <div class="col-md-12">
                <h3 class="h2 font-weight-light"><b class="font-weight-bold">Sorry!</b> the article may not found because of the following reasons:</h3>
                <ul type="square">
                    <li class="font-weight-light">Seeking for activation</li>
                    <li class="font-weight-light">Moved permanently</li>
                    <li class="font-weight-light">Blocked/Removed by the member</li>
                </ul>
                <p class="font-weight-light">If not the reason, please contact the <b class="font-weight-bold">Learn from Developers administrator team</b>.</p>
                <a href="./index.php" class="btn btn-lg btn-secondary">Go to Home <span class="fa fa-home"><span></a>
            </div>
        </section>
        <?php        
            }
        ?>
        <?php require_once "./layouts/share.php"; ?>
        <?php require_once "./layouts/subscription.php"; ?>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
    <script>
        $(document).ready(function () {
            <?php if(!empty($_SESSION['laererg'])){ ?>
                setTimeout(function () {
                    $.notify('Welcome <?=$_SESSION['laererg'] ?>, Good to see you again.','success');
                    $('#subscribemdl').modal('hide');
                },1000);
            <?php } else if(empty($_SESSION['cnx'])){?>
                $.notify('Hai, Please enter your details to proceed.','info');
                $('#subscribemdl').modal('show');    
            <?php } else{ ?>
                $.notify('Welcome <?=$_SESSION['cnx'] ?>, Good to see you again.','success');    
            <?php }?>
            function bookmarkthis() {
                pageTitle = document.title;
                pageURL = document.location;
                try {
                    eval("window.external.AddFa-vorite(pageURL, pageTitle)".replace(/-/g, ''));
                }
                catch (e) {
                    try {
                        window.sidebar.addPanel(pageTitle, pageURL, "");
                    }
                    catch (e) {
                        if (typeof (opera) == "object") {
                            a.rel = "sidebar";
                            a.title = pageTitle;
                            a.url = pageURL;
                            return true;
                        } else {
                            alert('Press ' + (navigator.userAgent.toLowerCase().indexOf('mac') != -1 ? 'Cmd' : 'Ctrl') + '+D to bookmark this page.');
                        }
                    }
                }
                return false;
            }
        });
    </script>
</body>
</html>
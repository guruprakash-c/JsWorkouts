<?php 
//error_reporting(0);
require_once "./controller/Posts.php";
require_once "./controller/Miscellaneous.php";

ob_start();

$misc = new Miscellaneous();
$misc->Consent();

$postObj = new Posts();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Archive &ndash; Learn from Developers</title>
    <?php require_once "./layouts/head.php"; ?>
</head>

<body>
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <main class="container mt-4 search-body" style="margin-top: 7em !important;">
        <section class="archivelist">
            <?php
                if(!empty($_GET['year'])){
                    $archives = $postObj->GetArchives($_GET['year']);
                    if(mysqli_num_rows($archives)>0){
                    ?>
                    <article id="<?=$_GET['year'] ?>" class="archiveyear">
                    <h4 class="display-4"><?=$_GET['year'] ?></h4>
                    <p>
                        <ul type="square">
                            <?php 
                                while($archivePosts = mysqli_fetch_assoc($archives)){
                            ?>
                                <li>
                                    <a href="<?='posts.php?p='.$archivePosts['ID'] ?>" rel="archive"><?=$archivePosts['Title'] ?></a>
                                </li>
                            <?php 
                            } 
                            ?>
                        </ul>
                    </p>
                    </article>
                    <?php         
                    }
                    else{
                        echo '<div class="lead"><p>No articles or videos found for '.$_GET['year'].'</p></div>';    
                        header('Refresh:3;url=index.php');
                    }
                }
                else{
                    header('Location: index.php');
                }
            ?>
        </section>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
</body>

</html>
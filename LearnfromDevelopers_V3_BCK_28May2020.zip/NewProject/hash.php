<?php 
/*echo $password =  base64_encode('c.guruprakash@yahoo.com');  
$ws = str_replace('=', '', $password);
base64_decode($ws);
echo strlen($password);
//$hash_default_salt = hash('sha512',$password,false); 

//echo '<li>'.$hash_default_salt.'</li>';
//password_verify('Password', $hash_default_salt); 
*/
hash('sha512',trim('rjagadeesh30@gmail.com'),false);
echo hash('sha512',trim('Guru@1234567'),false);
//date_default_timezone_set('Asia/Colombo');
//$date = date('Y-m-d h:i:s');
//echo date('Y-m-d h:i:s', strtotime($date. ' + 3 days'));
$output = shell_exec('nslookup myip.opendns.com resolver1.opendns.com');
$chunk1 = explode('Name',$output)[1];
$chunk2 = explode('Address: ' , $chunk1)[1];
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$pblc= trim($chunk2,' ');
$pvt = trim(gethostbyname($hostname),' ');
$ipaddress = $pblc.'|'.$pvt; 

$meta = get_meta_tags('http://localhost/PHP/NewProject/posts.php?p=0HkcR05052');
/*echo '<pre>';
foreach ($meta as $key => $value) {
    echo '<li>'.$value.'</li>';
}  
echo '</pre>';
*/
?>
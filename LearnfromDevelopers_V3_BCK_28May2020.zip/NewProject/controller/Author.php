<?php 
require "./model/Authors.php";

class Author{
    function Authors($authorId=""){
        $authorObj = new Authors();
        if(!empty($authorId)){
            return $authorObj->Author($authorId);
        }
        else{
            return $authorObj->Author("");
        }
    }
    function TopAuthors($size = 5){
        $authorObj = new Authors();
        return $authorObj->TopAuthor($size);
    }
    function NewAuthor($author = array()){
        $authorObj = new Authors();
        return $authorObj->AddAuthor($author);
    }
}
?>
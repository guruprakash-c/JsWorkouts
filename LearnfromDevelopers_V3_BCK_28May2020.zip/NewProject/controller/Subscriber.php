<?php 
//error_reporting(0);
require "./model/Subscribers.php";

class Subscriber{
    function Subscription($subscriber = array()){
        $subscriberObj = new Subscribers();
        return $subscriberObj->AddSubscriber($subscriber);
    }
    function GetSubscribers(){
        $subscribers = new Subscribers();
        return $subscribers->Subscriber();
    }
    function Login($subscriber = array()){
        $subscriberObj = new Subscribers();
        return $subscriberObj->Signin($subscriber);
    }
    function GetPassword($subscriber = array()){
        $subscriberObj = new Subscribers();
        return $subscriberObj->RecoverAcct($subscriber);
    }
    function ActivateUser($subscriber = array()){
        $subscriberObj = new Subscribers();
        return $subscriberObj->Status($subscriber);
    }
    function UpdateUser($subscriber = array()){
        $subscriberObj = new Subscribers();
        $profiler = array(
                        'username' => $subscriber['uname'],
                        'userpwd' => $subscriber['usrpsswd'],
                        'nwpaswd' => $subscriber['nwpsswd']
                    );
        return $subscriberObj->UpdateProfile($profiler);
    }
}
?>
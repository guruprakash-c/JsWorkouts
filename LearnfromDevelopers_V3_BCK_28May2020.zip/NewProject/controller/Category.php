<?php 
require "./model/Categories.php";

class Category{
    function Categories($categoryId){
        $categoryObj = new Categories();
        if(!empty($categoryId)){
            return $categoryObj->Category($categoryId);
        }
        else{
            return $categoryObj->Category("");
        }
    }
    function TopCategories($size = 5){
        $categoryObj = new Categories();
        return $categoryObj->TopCategory($size);
    }
    function NewCategory($category = array()){
        $categoryObj = new Categories();
        return $categoryObj->AddCategory($category);
    }
    function CategoryCount($type,$category){
        $categoryObj = new Categories();
        return $categoryObj->GetCount($type,$category);
    }
}
?>
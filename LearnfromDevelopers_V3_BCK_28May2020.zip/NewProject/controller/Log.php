<?php 
require "./model/Logs.php";

class Log{
    function GetLogs($logId=""){
        $response = null;
        $log = new Logs();
        if(!empty($logId)){
            $response = $log->Log($logId);
        }
        else{
            $response = $log->Log("");
        }
        return $response;
    }
}
?>
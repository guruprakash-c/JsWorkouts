<?php 
require "./model/Analytics.php";

class Views{
    function AddViews($postId,$uIp){
        $response = null;
        $views = new Analytics();
        if(!empty($postId)){
            $response = $views->AddPageViews($postId,$uIp);
        }
        return $response;
    }
    function PostViews($postId,$userIp=""){
        $response = null;
        $views = new Analytics();
        if(!empty($postId)){
            $response = $views->PageViews($postId,$userIp);
        }
        else{
            $response = $views->PageViews("","");
        }
        return $response;
    }
    function FetchIP() {
        $ipaddress = null;
        try{
        /*if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if(getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if(getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if(getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
        else if(getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = null;*/
        
        $output = shell_exec('nslookup myip.opendns.com resolver1.opendns.com');
        $chunk1 = explode('Name',$output)[1];
        $chunk2 = explode('Address: ' , $chunk1)[1];
        $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
        $pblc= trim($chunk2,' ');
        $pvt = trim(gethostbyname($hostname),' ');
        $ipaddress = $pblc.'|'.$pvt;     
        }
        catch(Exception $ex){
            $ipaddress = null;
        }
        return $ipaddress;
    }
    function UserViews($id){
        $postObj = new Articles();
        $response = null;
        if(!empty($id)){
            $response = $postObj->UserViews($id);
        }
        return $response;
    }
}
?>
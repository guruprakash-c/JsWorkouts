<?php 
//error_reporting(0);
require_once "./controller/Author.php";
require_once "./controller/Posts.php";
require_once "./controller/Miscellaneous.php";

$misc = new Miscellaneous();
$misc->Consent();

session_start();
$authorObj = new Author();
$authorPosts = new Posts();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Authors &ndash;Learn from Developers</title>
    <?php require_once "./layouts/head.php"; ?>
</head>

<body>
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <main class="container mt-4 search-body" style="margin-top: 7em !important;">
        <section class="clearfix mb-2">
            <span class="h3 float-left"><span class="fa fa-users mr-1"></span>Authors</span>
            <span class="h3 float-right">
                <?php if(!empty($_SESSION['laererg'])){ ?>
                <button type="button" class="btn btn-success" data-toggle="collapse" data-target="#addauthor" aria-expanded="false" aria-controls="addauthor">
                    <span class="fa fa-plus mr-1"></span>Add Authors
                </button>    
                <?php } ?>
            </span>
        </section>
        <?php 
            if(!empty($_SESSION['laererg'])){
                if($_SERVER['REQUEST_METHOD']==='POST'){
                    if(!empty($_POST['aTitle']) && !empty($_POST['aDtls']) && !empty($_POST['aPhoto'])){
                        
                        $author = array(
                            'Author'=>$_POST['aTitle'],
                            'Details'=>$_POST['aDtls'],
                            'Photo'=>$_POST['aPhoto'],
                            'FB'=>(!empty($_POST['aFb']))?$_POST['aFb']:'',
                            'Tw'=>(!empty($_POST['aTw']))?$_POST['aTw']:'',
                            'Website'=>(!empty($_POST['asite']))?$_POST['aSite']:''
                        );
                        $response = $authorObj->NewAuthor($author);
                        switch ($response) {
                            case -1:
                                echo '<div class="alert alert-warning alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> The Author already exists.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                break;
                            case 0:
                                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> The Author failed to add.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                break;
                            case 1:
                                echo '<div class="alert alert-success alert-dismissible fade show" role="alert"> <strong>Success!</strong> The Author added.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                break;
                        }
                    }  
                }
        ?>
            <section class="row mt-3" id="addauthor">
                <form name="authorform" id="authorform" method="POST" enctype="multipart/form-data" class="col-md-12 mx-auto card">
                    <section class="card-header">
                        <h3>New Author</h3>
                    </section>
                    <section class="card-body">
                        <div class="col-md-12 md-offset-2">
                            <div class="form-group mt-2 mb-2">
                                <label for="aTitle">Author Name <span class="text-danger">*</span></label>
                                <input type="text" name="aTitle" id="aTitle" placeholder="Name of the Author"
                                    class="form-control form-control-sm" maxlength="50"
                                    oninvalid="this.setCustomValidity('Please enter your name of the author.')"
                                    oninput="this.setCustomValidity('')" required />
                                <p>max. 50 characters</p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <label for="cDtls">Description <span class="text-danger">*</span></label>
                                <textarea name="aDtls" id="aDtls" placeholder="Bio"
                                    class="form-control form-control-sm" maxlength="500"
                                    oninvalid="this.setCustomValidity('Please enter something about your author.')"
                                    oninput="this.setCustomValidity('')" rows="5" cols="12" required></textarea>
                                <p>max 500 characters</p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <label for="aPhoto">Author Photo<span class="text-danger">*</span></label>
                                <input type="url" name="aPhoto" id="aPhoto" placeholder="Author photo include http(s)://"
                                    class="form-control form-control-sm imgurl"
                                    oninvalid="this.setCustomValidity('Please enter the url of author photo image.')"
                                    oninput="this.setCustomValidity('')" required />
                                <p>*.jpeg,.png,.jpg,.svg are allowed formats</p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <label for="aFb">Facebook Profile/Page Url<span class="text-primary">(optional)</span></label>
                                <input type="url" name="aFb" id="aFb" placeholder="Facebook Profile/Page url"
                                    class="form-control form-control-sm"/>
                                <p>include http(s)://</p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <label for="aTw">Twitter Profile/Page Url<span class="text-primary">(optional)</span></label>
                                <input type="url" name="aTw" id="aTw" placeholder="Twitter Profile/Page url"
                                    class="form-control form-control-sm" />
                                <p>include http(s)://</p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <label for="aSite">Website <span class="text-primary">(optional)</span></label>
                                <input type="url" name="aSite" id="aSite" placeholder="Website url include http(s)://"
                                    class="form-control form-control-sm"/>
                            </div>
                        </div>
                    </section>
                    <section class="card-footer">
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <button type="submit" class="btn btn-primary btn-lg mr-1">Add Author</button>
                                <button type="reset" class="btn btn-danger btn-lg ml-1">Cancel</button>
                            </div>
                        </div>
                    </section>
                </form>
            </section>
        <?php        
            }
            if(!empty($_GET['a'])){
                $responses = $authorPosts->GetSearch("","",$_GET['a']);
                if($responses != null){
                    if (mysqli_num_rows($responses) > 0) {
                    echo '<p class="lead">about <em class="font-weight-bold">'.mysqli_num_rows($responses).'</em> result(s)</p>';
                    ?>
                    
                    <section class="row mt-2 mb-2 articles">
                        <?php                 
                            while($posts = mysqli_fetch_assoc($responses)) {
                        ?>
                            <article class="col-md-4 mt-3 mb-3 article">
                                <a href="<?='./posts.php?p='.$posts['ID'] ?>" class="mt-0">
                                    <img src="<?=$posts['Banner'] ?>" style="width: 100%; height: 200px;" class="img-thumbnail border-0 mb-3"
                                        alt="<?=$posts['Title'] ?>" title="<?=$posts['Title'] ?>" />
                                    <h3 class="h3 article-title"><?=$posts['Title'] ?></h3>
                                    <p class="featured-muted"><?php 
                                        $summary = $posts['Summary'];
                                        $smyLen = strlen($summary);
                                        echo substr($summary,0,($smyLen<200)?$smyLen:300).'&hellip;';
                                    ?></p>
                                </a>
                                <div class="media">
                                    <img src="<?=$posts['Icon'] ?>" style="width: 40px; height: 40px;"
                                        class="img-thumbnail rounded-circle mr-3" alt="<?=$authorPosts->AlterNateName($posts['Title']) ?>">
                                    <div class="media-body featured-muted">
                                        <h5 class="mt-0"><a href="<?='./authors.php?a='.str_replace(' ','',$posts['Author']) ?>"><?=$posts['Author'] ?></a></h5>
                                        <time><?=$authorPosts->JustNowTiming($posts['Date']) ?></time> 
                                        <?=($posts['Type'] == 'Article') ? '&bull; '.$authorPosts->ReadingTime($posts['Description']).' to read' : '' ?>
                                    </div>
                                </div>
                            </article>
                        <?php    
                            }
                        ?>
                    </section>
                    <?php    
                    }
                    else{
                ?>
                    <section class="row jumbotron bg-info shadow">
                        <div class="col-md-12 text-dark">
                            <h3 class="h2 font-weight-light"><b class="font-weight-bold">Sorry!</b> the results may not found because of the following reasons:</h3>
                            <ul type="square">
                                <li class="font-weight-light">Seeking for activation</li>
                                <li class="font-weight-light">Moved permanently</li>
                                <li class="font-weight-light">Blocked/Removed by the member</li>
                            </ul>
                            <p class="font-weight-light">If not the reason, please contact the <b class="font-weight-bold">Learn from Developers Team</b>.</p>
                            <a href="./index.php" class="btn btn-lg btn-secondary">Go to Home <span class="fa fa-home"><span></a>
                        </div>
                    </section>
                <?php        
                    }
                }
                else{
                   echo '<div class="lead"><h3>No results containing all your search terms were found.</h3> <p> Your search did not match any article(s)/video(s).</p> <ul><li>Make sure that all words are spelled correctly.</li><li>Try different keywords.</li><li>Try more general keywords.</li></ul></div>'; 
                }
            }
            else{
        ?>
        <section class="row mt-0 authorsection">
            <?php 
                $dataAuthor = $authorObj->Authors();
                if (mysqli_num_rows($dataAuthor) > 0) {
                    while($autr = mysqli_fetch_assoc($dataAuthor)) {
            ?>
                    <section class="col-md-4 mt-3 mb-3 mr-0">
                        <a href="<?='./authors.php?a='.str_replace(' ','',$autr['Author'])  ?>" class="authorlink">
                            <div class="media">
                                <img src="<?=$autr['Photo'] ?>" style="width: 100px; height: 100px;" class="img-thumbnail mr-3" alt="<?=$autr['Author'] ?>">
                                <div class="media-body featured-muted">
                                    <h3 class="mt-0"><?=$autr['Author'] ?></h3>
                                    <span class="text-muted">
                                        <?php 
                                            $authorBio = $autr['Bio'];
                                            $bioSize = strlen($authorBio);
                                            echo substr($authorBio,0,($bioSize < 100) ? $bioSize : 100).'&hellip;';
                                        ?>
                                    </span>
                                </div>
                            </div>
                        </a>
                    </section>
            <?php                      
                    }
                } 
                else {
                    echo "Sorry! No Author(s) added.";
                }
            ?>
        </section>
        <?php 
            }
        ?>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
    <script>
        Scroller('.authorsection','.authorlink',12);
        Scroller('.articles','.article',6);
    </script>
</body>
</html>
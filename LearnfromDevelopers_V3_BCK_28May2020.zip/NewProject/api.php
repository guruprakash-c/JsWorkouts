<?php
error_reporting(E_ALL);

header('Content-Type: application/json');

require_once "./controller/Posts.php";

$response = array(); 
try{
    if(!empty($_POST['url'])){
        $chkPost = new Posts();
        $data = $chkPost->CheckPost($url);
        if(mysqli_num_rows($data) > 0){
            $response = array(
                'exists'=>1
            );
        }
        else{
            $response = array(
                'exists'=>0
            );
        }
    }
    else{
        $response = array(
            'exists'=>-1
        );
    }    
}
catch(Exception $ex){
    $response = array(
        'exists'=>-2
    );
}
echo json_encode($response);
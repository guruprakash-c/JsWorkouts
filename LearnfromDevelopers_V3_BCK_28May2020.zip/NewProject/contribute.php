<?php 
//error_reporting(0);
require_once "./controller/Category.php";
require_once "./controller/Author.php";
require_once "./controller/Posts.php";
require_once "./controller/Miscellaneous.php";
require_once "./controller/Subscriber.php";

ob_start();
if(!isset($_SESSION)){
    session_start();
}

$subs = new Subscriber();

$misc = new Miscellaneous();
$misc->Consent();

$postObj = new Posts();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contribution &ndash; Learn from Developers</title>
    <?php require_once "./layouts/head.php"; ?>
    <link href="./assets/editor.css" rel="stylesheet" />
</head>
<body>
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <main class="container mt-4 contribute-body" style="margin-top: 0em !important;">
        <?php 
            if(!empty($_SESSION['laererg'])){
                if($_SERVER['REQUEST_METHOD']==='POST'){
                    if(!empty($_POST['pTitle']) && 
                       !empty($_POST['pCagy']) && 
                       !empty($_POST['pAuthor']) && 
                       !empty($_POST['pType']) && 
                       !empty($_POST['pSmy']) && 
                       !empty($_POST['pType']) && 
                       (!empty($_POST['pDesc']) || !empty($_POST['vDesc'])) && 
                       !empty($_POST['pKwds']) && 
                       !empty($_POST['pBnr']) && 
                       !empty($_POST['pRef'])){
                        $postBody = $_POST['pSmy'];
                        if(strtolower($_POST['pType']) == 'video') {
                            $postBody = $_POST['vDesc'];
                        }
                        else if(strtolower($_POST['pType']) == 'article') {        
                            $postBody = $_POST['pDesc'];
                        }
                        // else{
                        //     $postBody = ;
                        // }
                        $article = array(
                            'Title'=>$_POST['pTitle'],
                            'Category'=>$_POST['pCagy'],
                            'Author'=>$_POST['pAuthor'],
                            'Type'=>$_POST['pType'],
                            'Summary'=>$_POST['pSmy'],
                            'Description'=>$postBody,
                            'Keywords'=>$_POST['pKwds'],
                            'Poster'=>$_POST['pBnr'],
                            'Source'=>$_POST['pRef'],
                            'Status'=>'direct'
                        );
                        $response = $postObj->NewPost($article);
                        switch ($response) {
                            case -1:
                                echo '<div class="alert alert-info alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> The Article/Video you are try to add already exists.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                break;
                            case 0:
                                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"> <strong>Failed!</strong> Something went wrong, please try later.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                break;
                            case 1:
                                echo '<div class="alert alert-success alert-dismissible fade show" role="alert"> <strong>Congratulations!</strong> The Article/Video has been added successfully.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                break;
                        }
                    }  
                }
        ?>
        <div class="card">
            <div class="card-header h2">
                <h3>Publish your article</h3>
            </div>
            <div class="card-body">
                <form name="contributeform" id="contributeform" method="POST" enctype="multipart/form-data">
                    <section class="row mt-0">
                        <div class="col-md-8">
                            <div class="form-group mt-2 mb-2">
                                <label for="pRef">Source Url <span class="text-danger">*</span></label>
                                <input type="url" name="pRef" id="pRef" placeholder="include http(s)://"
                                    class="form-control form-control-sm"
                                    oninvalid="this.setCustomValidity('Please enter reference url of your article.')"
                                    oninput="this.setCustomValidity('')" required />
                            </div>
                        </div>
                        <div class="col-md-4 statusSec">
                            <br/>
                            <div class="mt-3 mb-0 text-success isavail blink h5"></div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mt-2 mb-2">
                                <label for="pCagy">Category <span class="text-danger">*</span></label>
                                <select name="pCagy" id="pCagy"
                                    class="custom-select custom-select-sm mb-2"
                                    oninvalid="this.setCustomValidity('Please choose your category of the post.')"
                                    oninput="this.setCustomValidity('')" required>
                                        <option value="">Categories</option>
                                        <?php
                                            $CategoryObj = new Category();
                                            $dataCagy = $CategoryObj->Categories("");
                                            if(mysqli_num_rows($dataCagy) > 0){
                                                while($cagy=mysqli_fetch_assoc($dataCagy)){
                                                    echo '<option value="'.$cagy['ID'].'" data-ico="'.$cagy['Icon'].'">'.$cagy['Category'].'</option>';
                                                }
                                            }
                                            else{
                                                echo '<option value="-1" data-ico="./assets/uncategory.png">Uncategorize</option>';
                                            }
                                        ?>
                                </select>
                                <img id="cicoPvw" class="img-thumbnail border" style="width: 40px; height: 40px" alt=""/> 
                                <span class="px-1 py-1 <?=(empty($_SESSION['laererg'])?'d-none':'') ?>"><a href="./categories.php" class="text-primary"><span class="fa fa-plus-circle"></span> Add New Category</a></span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mt-2 mb-2">
                                <label for="pAuthor">Author <span class="text-danger">*</span></label>
                                <select name="pAuthor" id="pAuthor"
                                    class="custom-select custom-select-sm mb-2"
                                    oninvalid="this.setCustomValidity('Please choose your author of the post.')"
                                    oninput="this.setCustomValidity('')" required>
                                        <option value="">Authors</option>
                                        <?php
                                            $AuthorObj = new Author();
                                            $dataAutr = $AuthorObj->Authors("");
                                            if(mysqli_num_rows($dataAutr) > 0){
                                                while($autr=mysqli_fetch_assoc($dataAutr)){
                                                    echo '<option value="'.$autr['ID'].'" data-ico="'.$autr['Photo'].'">'.$autr['Author'].'</option>';
                                                }
                                            }
                                            else{
                                                echo '<option value="-1" data-ico="./assets/anonymous.png">Anonymous</option>';
                                            }
                                        ?>
                                </select>
                                <img id="aicoPvw" class="img-thumbnail border" style="width: 40px; height: 40px" alt=""/>
                                <span class="px-1 py-1 <?=(empty($_SESSION['laererg'])?'d-none':'') ?>"><a href="./authors.php" class="text-primary"><span class="fa fa-plus-circle"></span> Add New Author</a></span> 
                            </div>
                        </div>
                        <div class="col-md-4 optionSec">
                            <div class="form-group mt-2 mb-2">
                                <label for="type">Type <span class="text-danger">*</span></label><br/>
                                <label> 
                                    <input type="radio" name="pType" value="Video" required/>
                                    Video
                                </label> &nbsp;
                                <label>
                                    <input type="radio" name="pType" value="Article" required/>
                                    Article
                                </label><br/>   
                                <p class="form-text text-muted">select a type</p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <label for="pTitle">Title <span class="text-danger">*</span></label>
                                <input type="text" name="pTitle" id="pTitle" placeholder="Title"
                                    class="form-control form-control-sm" maxlength="300"
                                    oninvalid="this.setCustomValidity('Please enter your title for the post.')"
                                    oninput="this.setCustomValidity('')" required />
                                <p>max. 300 characters</p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group mt-2 mb-2">
                                <label for="pSmy">Summary <span class="text-danger">*</span></label>
                                <textarea name="pSmy" id="pSmy" placeholder="Summary" maxlength="500"
                                    class="form-control form-control-sm" style="max-height: 400px; min-height: 200px; resize: vertical;"  
                                    oninvalid="this.setCustomValidity('Please enter summary about your article.')"
                                    oninput="this.setCustomValidity('')" required></textarea>
                                <p>max. 500 characters</p>
                            </div>
                        </div>
                        <div class="col-md-12 articleDesc">
                            <div class="form-group mt-2 mb-2">
                                <label for="pDesc">Description <span class="text-danger">*</span></label>
                                <textarea name="pDesc" id="pDesc" placeholder="Description" style="max-height: 400px" class="form-control form-control-sm"
                                    oninvalid="this.setCustomValidity('Please enter body of your article.')"
                                    oninput="this.setCustomValidity('')"></textarea>
                            </div>
                        </div>
                        <div class="col-md-12 videoDesc">
                            <div class="form-group mt-2 mb-2">
                                <label for="vDesc">Video <span class="text-danger">*</span></label>
                                <input type="url" name="vDesc" id="vDesc" placeholder="Video Embed Url"
                                    class="form-control form-control-sm"
                                    oninvalid="this.setCustomValidity('Please enter video url.')"
                                    oninput="this.setCustomValidity('')"/>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mt-2 mb-2">
                                <label for="pKwds">Keyword(s) <span class="text-danger">*</span></label>
                                <input type="text" name="pKwds" id="pKwds" placeholder="Keyword(s)"
                                    class="form-control form-control-sm" maxlength="500"
                                    oninvalid="this.setCustomValidity('Please enter your keyword(s) related to your article.')"
                                    oninput="this.setCustomValidity('')" required />
                                <p>separate each keywords by comma(,)</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mt-2 mb-2">
                                <label for="pBnr">Featured Image <span class="text-danger">*</span></label>
                                <input type="url" name="pBnr" id="pBnr" placeholder="include http(s)://"
                                    class="form-control form-control-sm imgurl"
                                    oninvalid="this.setCustomValidity('Please enter url of the featured image.')"
                                    oninput="this.setCustomValidity('')" required />
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mt-2 mb-2">
                                <label for="pFeatured"><br />
                                    <input type="checkbox" name="pFeatured" id="pFeatured" /> Is Featured
                                    <span class="text-primary">(optional)</span>
                                </label><br />
                                <p>check-in to highlight your article</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mt-2 mb-2">
                                <label for="pDft"> 
                                    <input type="radio" idate="pDft" name="pDft" value="draft"/>
                                    Save as draft
                                </label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <img class="img-fluid mt-2 mb-2" style="height: 200px; width: 100%;" id="bnrPvw" />
                        </div>
                        <div class="col-md-4">
                            <div class="form-group mt-2 mb-2 float-right">
                                <button type="submit" class="btn btn-primary btm-sm">
                                    Publish article <span class="fa fa-paper-plane"></span>
                                </button>
                                <button type="reset" class="btn btn-outline-danger btm-sm">
                                    Cancel
                                </button>
                            </div>
                        </div>
                    </section>
                </form>
            </div>
        </div>
        <!--div class="divider text-center" data-content="OR"></div>        
        <div class="card mt-3">
            <div class="card-header h2">
                <h3>Upload LFD File</h3>
            </div>
            <div class="card-body">                            
                <a href="./bulkupload.php" class="btn btn-info btn-lg" role="button">Upload</a>
            </div>
        </div-->
        <?php        
        }
        else{
        ?>
        <section class="row mt-3 border py-3 px-3">
            <section class="col-md-6 md-offset-2 mt-3 mb-3 mr-0">
                <h3 class="text-info">
                    Build a real audience
                </h3>
                <p class="mb-5">
                    <ul type="square">
                        <li>Free member registration & login</li>
                        <li>Free Subscription</li>
                        <li>Know your audience</li>
                        <li>Hang onto your memories</li>
                        <li>Come for what you love</li>
                        <li>Come for what you love</li>
                        <li>Stay for what you discover</li>
                    </ul>
                </p>
                <a href="javascript:void(0);" role="button" class="btn btn-block btn-info btn-lg">
                    <span class="fa fa-windows"><span> Signin with O365
                </a>
            </section>
            <section class="col-md-6 md-offset-2 mt-3 mb-3 mr-0">
                <h3>Sign in</h3>
                <?php 
                    if($_SERVER['REQUEST_METHOD']==='POST'){
                        if(!empty($_POST['username']) && !empty($_POST['userpswd'])){
                            $articleUsrs = array(
                                'username'=>htmlspecialchars($_POST['username'], ENT_QUOTES, 'UTF-8'),
                                'userpasswd'=>htmlspecialchars($_POST['userpswd'], ENT_QUOTES, 'UTF-8')
                            );
                            $response = $subs->Login($articleUsrs);
                            switch ($response) {
                                case 3:
                                    $_SESSION['laererg'] = trim($_POST['username']);
                                    $admin = $_SESSION['laererg'];
                                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert"> <strong>Congratulations!</strong> You have successfully signed in.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';          
                                    break;
                                case -2:
                                    $_SESSION['cnx'] = trim($_POST['username']);
                                    echo '<div class="alert alert-info alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> You are not allowed to contribute us.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                    break;
                                default:
                                    $_SESSION['laererg'] = '';
                                    $_SESSION['cnx'] = '';
                                    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> Invalid credentials.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                    break;
                            }
                            header("Refresh:2; url=dashboard.php");
                        }
                    }

                    if(!empty($_POST['fEmail'])){
                        if($_SERVER['REQUEST_METHOD']==='POST'){
                                $forgotUsrs = array(
                                    'username' => htmlspecialchars($_POST['fEmail'], ENT_QUOTES, 'UTF-8')
                                );
                            $response = $subs->GetPassword($forgotUsrs);
                            if($response) {
                                //$resp1 = explode('|', $response)[0]; 
                                $resp2 = explode('|', $response)[1]; 
                                switch ($resp2) {
                                    case -1:
                                        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> Invalid email address.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                        break;
                                    case 0:
                                        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"> <strong>Sorry!</strong> Something went wrong.<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                        break;
                                    case 1:
                                        echo '<div class="alert alert-success alert-dismissible fade show" role="alert"> <strong>Congratulations!</strong> Please check your inbox, we have send your password('.$resp1.').<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
                                        break;
                                }
                            }
                        }
                    }
                ?>
                <form name="signinform" id="signinform" method="POST" enctype="multipart/form-data">
                    <label for="username">Username/Email address&nbsp;<span class="text-danger">*</span></label>
                    <input type="email" name="username" id="username" class="form-control mb-3" placeholder="Username/Email address" oninvalid="this.setCustomValidity('Please enter your Username/Email address');" oninput="this.setCustomValidity('');" required/> 
                    <label for="userpswd">Password&nbsp;<span class="text-danger">*</span>
                    </label>
                    <input type="password" name="userpswd" id="userpswd" class="form-control mb-1" placeholder="Password" oninvalid="this.setCustomValidity('Please enter your One Time Password(OTP).');" oninput="this.setCustomValidity('');" required/> 
                    <div class="clearfix mb-3">
                        <div class="form-group float-left form-check">
                            <input type="checkbox" class="form-check-input" id="showpwd">
                            <label class="form-check-label" id="pwdlbl" for="showpwd">Show Password</label>
                        </div>
                        <span class="text-muted float-right">
                            <a href="javascript:void(0);" role="button" data-toggle="modal" data-target="#forgotmdl" class="text-sm">Login with OTP</a>
                        </span>
                    </div>
                    <button type="submit" class="btn btn-block btn-primary btn-lg">
                        <span class="fa fa-sign-in"></span> Signin
                    </button>
                </form>
            </section>
            <section class="col-md-2 mt-3 mb-3 mr-0">
                <a href="javascript:void(0);" role="button" class="btn btn-block btn-light border btn-lg">
                    <span class="fa fa-google"></span> Google
                </a>
            </section>
            <section class="col-md-2 mt-3 mb-3 mr-0">
                <a href="javascript:void(0);" role="button" class="btn btn-block btn-light border btn-lg">
                    <span class="fa fa-facebook"></span> Facebook
                </a>
            </section>
            <section class="col-md-2 mt-3 mb-3 mr-0">
                <a href="javascript:void(0);" role="button" class="btn btn-block btn-light border btn-lg">
                    <span class="fa fa-twitter"></span> Twitter
                </a>
            </section>
            <section class="col-md-3 mt-3 mb-3 mr-0">
                <a href="javascript:void(0);" role="button" class="btn btn-block btn-success btn-lg">
                    <span class="fa fa-check-square-o"></span> Account Activation
                </a>
            </section>
            <section class="col-md-3 mt-3 mb-3 mr-0">
                <a href="javascript:void(0);" role="button" class="btn btn-block btn-warning btn-lg">
                    <span class="fa fa-star"></span> Upgrade Membership
                </a>
            </section>
        </section>
        <?php    
        }
        ?>

        <?php 
            require_once "./layouts/forgot.php";
        ?>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
    <script src="./assets/editor.js"></script>
    <script>
        var editor = new Jodit('#pDesc', { height: 400,beautifyHTML: true });
        var currpage = '<?=str_replace('.php','',basename($_SERVER['PHP_SELF'])) ?>';
        <?php if(!empty($_SESSION['laererg'])){ ?>
            if(currpage == 'contribute'){
                $('nav.mainmenubar').removeClass('fixed-top');
                $('#btn-contribute').html('<span class="fa fa-paper-plane"></span>');
                $('#btn-signout').html('<span class="fa fa-sign-out"></span>');
            }
            else{
                $('nav.mainmenubar').addClass('fixed-top');
                $('#btn-contribute').html('Contribute<span class="fa fa-paper-plane ml-1"></span>');
                $('#btn-signout').html('<span class="fa fa-sign-out mr-1"></span>Signout');
            }
        <?php } ?>
        $('#cicoPvw,#aicoPvw,#bnrPvw').hide();
        $('.articleDesc,.videoDesc').hide();
        $('.optionSec').show();
        $('input[type=radio][name=pType]').change(function () {
            var thisVal = ($(this).val()).toLowerCase();
            switch (thisVal) {
                case 'video':
                    $('.articleDesc').hide();
                    $('#pDesc').removeAttr('required');;
                    $('.videoDesc').show();
                    $('#vDesc').attr('required','required');
                    break;
                case 'article':
                    $('.videoDesc').hide();
                    $('#vDesc').removeAttr('required');;
                    $('.articleDesc').show();
                    $('#pDesc').attr('required','required');
                    break;
            }
        });
        $('input#pBnr').change(function () {
            
            if ($('input#pBnr').val() != '') {
                if($('input#pBnr').val().match(/\.(jpeg|jpg|svg|png)$/) != null){
                    $('img#bnrPvw').attr('src', './assets/loading.svg')
                                   .css({'width':'32px','height':'32px'})
                                   .show();
                    setTimeout(function () {
                        $('img#bnrPvw').attr('src', $('input#pBnr').val())
                                       .css({'width':'100%','height':'200px'})
                                       .show();
                    }, 5000);
                }
                else{
                    $('input#pBnr').val('').focus();
                }
            }
            else {
                $('#bnrPvw').hide();
            }
        });
        $('select#pCagy').change(function () {
            if ($('select#pCagy option:selected').val() != '') {
                $('img#cicoPvw').attr('src', './assets/loading.svg')
                                .css({'width':'32px','height':'32px'})
                                .show();
                setTimeout(function () {
                    $('img#cicoPvw').attr('src', $('select#pCagy option:selected').data('ico'))
                                    .css({'width':'40px','height':'40px'})
                                    .show();
                }, 5000);
            }
            else {
                $('#cicoPvw').hide();
            }
        });
        $('select#pAuthor').change(function () {
            if ($('select#pAuthor option:selected').val() != '') {
                $('img#aicoPvw').attr('src', './assets/loading.svg')
                                .css({'width':'32px','height':'32px'})
                                .show();
                setTimeout(function () {
                    $('img#aicoPvw').attr('src', $('select#pAuthor option:selected').data('ico'))
                                    .css({'width':'40px','height':'40px'})
                                    .show();
                }, 5000);
            }
            else {
                $('#aicoPvw').hide();
            }
        });
        $('.statusSec').hide();
        $('input#pRef').change(function(){
            if($('input#pRef').val() != undefined && $('input#pRef').val() != ''){
                var _url = $('input#pRef').val();
                $.ajax({
                    url: 'isexists.php',
                    method: 'POST',
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    data: {
                        url: _url
                    },
                    success: function(reponse){
                         var opt = reponse.exists;
                         switch (opt) {
                            case -2:
                            case -1:
                            case 1:
                                 $('.isavail').removeClass('text-success')
                                              .addClass('text-danger')
                                              .empty()
                                              .append('<span class="fa fa-times-circle mr-2 c'+opt+'"></span>Already exists');                                    
                                 break;
                             case 0:
                                $('.isavail') .addClass('text-success')
                                              .removeClass('text-danger')
                                              .empty()
                                              .append('<span class="fa fa-check-circle mr-2"></span>OK');
                                 break;
                         }
                         $('.statusSec').show();
                    },
                    error: function(err){
                        console.log(err.statusCode);
                    }
                });
            }
            else{
                $('input#pRef').focus();
            }
        });
    </script>
</body>
</html>
<?php 
if(!isset($_SESSION)){
    session_start();
}
require_once "DataConfig.php";
require_once "Logs.php";

class Analytics extends DataConfig{
    function AddPageViews($pId,$uIp){
        $postId = trim($pId);
        $response = null;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        $page = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        try{
            if(!empty($postId)){
                if($uIp != null){
                    $chunks = explode('|',$uIp);
                    $public = $chunks[0];
                    $private = $chunks[1]; 
                    $ssql = "SELECT DISTINCT COUNT(`viewId`) AS 'Views' FROM `tblviews` where pvtIp = '{$private}' AND publicIp = '{$public}' AND  `postId` = '{$postId}'";
                    $selectUser = mysqli_query($connection,$ssql);
                    if(mysqli_num_rows($selectUser) > 0){
                        $vsql = "UPDATE `tblViews` SET `postViews` = `postViews` + 1 WHERE pvtIp = '{$private}' AND publicIp = '{$public}' AND `postId` = '{$postId}'";
                        while($vData = mysqli_fetch_assoc($selectUser)){
                            $pgVws = $vData['Views'];
                            if($pgVws == 0){
                                if(!empty($_SESSION['uView'])){
                                    $vsql = "INSERT INTO `tblViews`(`postId`, `pvtIp`, `publicIp`, `postViews`) VALUES ('{$postId}','{$private}','{$public}',1)";
                                }
                                else{
                                    $vsql = "";
                                }
                            }
                        }
                        if(!empty($vsql)){
                            $response = mysqli_query($connection,$vsql);
                        }
                    }
                    else{
                        if(!empty($_SESSION['uView'])){
                            $vsql = "INSERT INTO `tblViews`(`postId`, `pvtIp`, `publicIp`, `postViews`) VALUES ('{$postId}','{$private}','{$public}',1)";
                        }
                        else{
                            $vsql = "";
                        }
                        if(!empty($vsql)){
                            $response = mysqli_query($connection,$vsql);
                        }
                    }
                }
            }
        }
        catch(Exception $ex){
            $log = new Logs();
            $log->AddLog($ex->getMessage(),$page,"UserVisits :: AddViews");
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
    function PageViews($pId){
        $response = null;
        $postId = trim($pId);
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        $page = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        try{
            $ssql = "SELECT DISTINCT v.`dateViewed` as 'Date', p.`articleTitle` as 'Post', v.`pvtIp` as 'PrivateIP', v.`publicIp` as 'PublicIP', v.`postViews` as 'Views' FROM `tblViews` AS v JOIN `tblposts` AS p on v.`postId` = p.`permaId`";
            if(!empty($postId)){
                $ssql = "SELECT DISTINCT v.`dateViewed` as 'Date', p.`articleTitle` as 'Post', v.`pvtIp` as 'PrivateIP', v.`publicIp` as 'PublicIP', v.`postViews` as 'Views' FROM `tblViews` AS v JOIN `tblposts` AS p on v.`postId` = p.`permaId` WHERE `postId` = '{$postId}'"; 
            }
            $response = mysqli_query($connection,$ssql);
        }
        catch(Exception $ex){
            $log = new Logs();
            $log->AddLog($ex->getMessage(),$page,"UserVisits :: GetViews");
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
}
?>
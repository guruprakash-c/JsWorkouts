<?php 
class DataConfig{
    private $serverName = 'localhost';
    private $userName = 'root';
    private $userPaswd= '';
    private $dBase = 'devdb';
    
    /*private $serverName = 'localhost';
    private $userName = 'id12845073_learnedit';
    private $userPaswd= 'Password@1234';
    private $dBase = 'id12845073_devdb';*/

    protected function Connection(){
        $conStr = mysqli_connect($this->serverName,$this->userName,$this->userPaswd,$this->dBase);
        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            exit;
        }
        return $conStr;
    }
    protected function GeneratePerma($len=32){
        $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charln = strlen($chars);
        $resultStr = '';
        for ($x = 0; $x < $len; $x++) {
            $resultStr .= $chars[rand(0, $charln - 1)];
        }
        return $resultStr.date('dmYhmstt');
    }

    protected function CloseConnection($conStr){
        return mysqli_close($conStr);
    }
}
?>
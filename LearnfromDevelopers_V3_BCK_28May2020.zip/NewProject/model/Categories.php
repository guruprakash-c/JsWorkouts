<?php  
require_once "DataConfig.php";
require_once "Logs.php";

class Categories extends DataConfig{

    function Category($categoryId=""){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $ssql = "SELECT `categoryId` as 'ID', `categoryName` as 'Category', `categoryIcon` as 'Icon', `categoryBanner` as 'Banner', `isBlocked` as 'Status' FROM `tblcategories` WHERE `isBlocked` <> 1  ORDER BY `categoryName` asc";
            if(!empty($categoryId)){
               $ssql = "SELECT `categoryId` as 'ID', `categoryName` as 'Category', `categoryIcon` as 'Icon', `categoryBanner` as 'Banner', `isBlocked` as 'Status' FROM `tblcategories` WHERE `categoryId` = {$categoryId}  ORDER BY `categoryName` asc"; 
            }
            $response = mysqli_query($connection,$ssql);
            
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Category :: Get");
            
            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
    function AddCategory($category = array()){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $name = $category['Category'];
            $icon = $category['Icon'];
            $banner = $category['Banner'];
            $isExists = $this->DoesExists(strtolower($name));
            if($isExists == 0){
                $isql = "INSERT INTO `tblcategories`(`categoryName`, `categoryIcon`, `categoryBanner`) VALUES ('{$name}','{$icon}','{$banner}')";
                mysqli_query($connection,$isql);
                $response = 1;
            }
            else{
                $response = -1;
            }
            
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Category :: Add");
            
            $response = $ex->getMessage()??0;
        }
        return $response;
    }
    function DoesExists($category){
        $isExists = false;
        
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        
        $chksql = "SELECT * FROM `tblcategories` WHERE LOWER(`categoryName`) = '{$category}'";
        $data = mysqli_query($connection,$chksql);
        $response = mysqli_num_rows($data);
        
        if($response > 0){
            $isExists = true;
        }
        else{
            $isExists = false;
        }
        return $isExists;
    }
    function UpdateCategory($category = array()){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $usql = "";
            $response = mysqli_query($usql);
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Category :: Update");
            
            $response = $ex->getMessage();
        }
    }
    function BlockCategory($categoryId){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $bsql = "";
            $response = mysqli_query($bsql);
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Category :: Block");
            
            $response = $ex->getMessage();
        }
    }
    function DeleteCategory($categoryId){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $dsql = "";
            $response = mysqli_query($dsql);
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Category :: Remove");
            
            $response = $ex->getMessage();
        }
    }
    function TopCategory($limit = 5){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $ssql = "SELECT c.`categoryName` as 'Category' FROM tblcategories c WHERE c.`isBlocked` <> 1 ORDER BY c.`categoryName` ASC LIMIT {$limit}"; 
            $response = mysqli_query($connection,$ssql);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Category :: Top");
            
            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
    function GetCount($type,$category){
        $response = null;
        if(!empty($type) && !empty($category)){
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            try{
                $ssql = "SELECT count(p.`permaId`) AS 'Articles' FROM `tblposts` AS p JOIN tblcategories AS c on p.`articleCategory` = c.categoryId WHERE p.`articleType` = '{$type}' AND c.categoryName = '{$category}' GROUP BY p.`articleCategory`"; 
                $response = mysqli_query($connection,$ssql);
            }
            catch(Exception $ex){
                //pass to logs
                $log = new Logs();
                $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                $log->AddLog($ex,$currPg,"Category :: Count");
                $response = $ex->getMessage();
            }
            finally{
                $dataObj->CloseConnection($connection);
            }
        }
        return $response;
    }
}
?>
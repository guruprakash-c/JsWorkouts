<?php 
//error_reporting(0);
require_once "DataConfig.php";
require "Mail/PHPMailer.php";
require "Mail/SMTP.php";
require_once "Logs.php";

class Subscribers extends DataConfig{
    function AddSubscriber($user=array()){
        $response = 0;
        $uResp = '';
        $adminAddress = "c.guruprakash@yahoo.com";
        if($user != null){
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $modUsr = array(
                        'username'=>$user['userName'],
                        'userpasswd'=>$user['userEmail']
                      );
            $uResp = $this->Signin($modUsr);
            $uid = $this->GetLastUser($user["userEmail"]);
            if($uid == null){ 
                $uName = $user["userName"];
                $uEMail = $user["userEmail"];
                $actKey = $dataObj->GeneratePerma(12);
                $uPswd = hash('sha512',trim($actKey),false);

                $isql = "INSERT INTO `tblusers`(`name`, `useremail`,`userPswd`, `actCode`,`usrRole`) VALUES ('{$uName}','{$uEMail}','{$uPswd}','{$actKey}',2)";

                $doesSend = $this->SendActivation($uEMail);
                mysqli_query($connection,$isql);
                if($doesSend == true){
                    $response = 1;
                }
                else{
                    $this->SendActivation($adminAddress,"Alert #1: Unable to send email in LFD.");
                    $response = 1;
                }
            }
            else{
                if(!empty($uResp)){
                    $response = $uResp;
                }
                else{
                    $response = -1;
                }
            }
        }
        return $response;
    }
    function Subscriber($logId){
            $response = 0;
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            try{
                $ssql = "SELECT l.`logId` as 'ID', l.`occurredDate` as 'Date',l.`functionName` as 'Function', l.`pageUrl` as 'Page', l.`logMessage` as 'Message', l.`isResolved` as 'Status' FROM `tbllogs` l ORDER BY l.`occurredDate` DESC";
                if(!empty($logId)){
                $lId = trim($logId);
                $ssql = "SELECT l.`logId` as 'ID', l.`occurredDate` as 'Date',l.`functionName` as 'Function', l.`pageUrl` as 'Page', l.`logMessage` as 'Message', l.`isResolved` as 'Status' FROM `tbllogs` l WHERE l.`logId` = {$lId} ORDER BY l.`occurredDate` DESC"; 
                }
                $response = mysqli_query($connection,$ssql);
            }
            catch(Exception $ex){
                //pass to logs
                $response = $ex->getMessage();
            }
            finally{
                $dataObj->CloseConnection($connection);
            }
            return $response;
    }
    private function GetLastUser($emailAddress){
        $userId = null;
        if(!empty($emailAddress)){
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $ssql = "SELECT DISTINCT u.`userId` as 'ID' FROM `tblusers` u WHERE `useremail` = '{$emailAddress}' LIMIT 1";
            $user = mysqli_query($connection,$ssql);
            if(mysqli_num_rows($user)>0){
                while($ussr = mysqli_fetch_assoc($user)){
                    $userId = $ussr['ID'];
                }
            }
        }
        return $userId;
    } 
    private function SendActivation($toAddress,$body=""){
        $response = false;
        if(!empty($toAddress)){
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $usrId = Subscribers::GetLastUser($toAddress);
            $userActCode = null;
            if($usrId != null){
                $ssql = "SELECT DISTINCT u.`name` as 'User', u.`actCode` as 'Code' FROM `tblusers` u WHERE `userId` = {$usrId} ORDER BY `subscribedOn` DESC LIMIT 1";
                $user = mysqli_query($connection,$ssql);
                if(mysqli_num_rows($user)>0){
                    while($ussr = mysqli_fetch_assoc($user)){
                        $userActCode = $ussr['Code'];
                        $userFName = $ussr['User'];
                    }
                }
                if($userActCode != null){
                    $postEMail = new PHPMailer();
                    $postEMail->isSMTP();
                    //Enable SMTP debugging
                    // SMTP::DEBUG_OFF = off (for production use)
                    // SMTP::DEBUG_CLIENT = client messages
                    // SMTP::DEBUG_SERVER = client and server messages
                    $postEMail->SMTPDebug = SMTP::DEBUG_SERVER;
                    $postEMail->Host = 'smtp.gmail.com';
                    $postEMail->Port = 587;
                    $postEMail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $postEMail->SMTPAuth = true;
                    $postEMail->Username = 'no1adnetwork@gmail.com';
                    $postEMail->Password = '@guRU990!';
                    $postEMail->setFrom('no1adnetwork@gmail.com', 'Learn from Developers');
                    $postEMail->addReplyTo('no-reply@learnfromDevelopers.com', 'Learn from Developers Support');
                    $postEMail->addAddress($toAddress, 'John Doe');
                    $postEMail->Subject = 'PHPMailer GMail SMTP test';
                    //$postEMail->msgHTML(file_get_contents('contents.html'), __DIR__);
                    $eMailBody = '<div style="background-color: rgba(25, 118, 210, 0.2) !important; padding: 12px; margin: 2px auto;"><header class="container" style="background: rgba(25, 118, 210, 1) !important; padding: 12px;"><img src="https://i.imgur.com/99Au6z2.png" class="mr-2" alt="Learn from Developers" title="Learn from Developers" style="width: 300px; height: 60px; vertical-align: middle;" /></header><main class="container" style="background-color: rgba(255, 255, 255, 1) !important; padding: 12px;"><h2 class="h2 font-weight-light">Hi <strong style="font-weight: 900">'.$userFName.'</strong></h2><h3>Just one more Step...</h3><h5>Copy the code below and paste in the activation field or goto <a href="./activation.php?c='.$userActCode.'" target="_blank">Activation page</a></h5><h5 style="padding: 12px; text-align: center; font-size: 24px; border: 2px dashed #1976d2; width: 300px; background: #f1f2f2; font-weight: 400;">'.$userActCode.'</h5></main><footer class="container" style="color: #777;background-color: rgba(255, 255, 255, 0.5) !important; padding: 12px;">&copy;<script>document.write(new Date().getFullYear());</script>Learn from Developers,All Rights Reserved. </footer></div>';
                    if(!empty($body)){
                        $postEMail->AltBody($body);
                    }
                    else{
                        $postEMail->msgHTML($eMailBody);
                    }
                    
                    //$postEMail->AltBody = 'This is a plain-text message body';
                    //Attach file
                    //$postEMail->addAttachment('images/phpmailer_mini.png');
                    if (!$postEMail->send()) {
                        $log = new Logs();
                        $log->AddLog('Email Error: '.$postEMail->ErrorInfo,"Subscription","Subscriber::Activation");
                    } else {
                        $response = true;
                    }
                }
            }   
        }
    }
    function Signin($user = Array()){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $uId = trim($user['username']);
            $uPwd = hash('sha512',trim($user['userpasswd']),false);
            $ssql = "SELECT DISTINCT u.`useremail` AS 'Email',u.`name` AS 'Name',r.`roleName` AS 'Role',u.`isactive` AS 'Status' FROM `tblusers` u JOIN `tblroles` r on u.`usrRole` = r.`roleId` WHERE u.`isactive` = 1 AND u.`useremail` = '{$uId}' AND u.`userPswd` = '{$uPwd}'";
            $usrS = mysqli_query($connection,$ssql);
            if(mysqli_num_rows($usrS) > 0){
                $cnt = mysqli_num_rows($usrS);
                while($ussrs = mysqli_fetch_assoc($usrS)){
                    $userId = $ussrs['Email'];
                    $userName = $ussrs['Name'];
                    $userRole = $ussrs['Role'];
                    switch($userRole){
                        case 'administrators':
                            $response = 3;
                        break;
                        case 'subscribers':
                            $response = -2;
                        break;
                        default:
                            $response = 0;
                        break;
                    }
                }
            }
            else{
                $response = 0;
            }
            
        }
        catch(Exception $ex){
            //pass to logs
            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }

    function RecoverAcct($user = Array()){
        date_default_timezone_set('Asia/Colombo');
        $currDate = date('Y-m-d h:i:s');
        $response = 0;
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            try{
                $uEml = trim($user['username']);
                $uId = '';
                $userCode = '';

                $ssql = "SELECT DISTINCT u.`userId` AS 'User', u.`actCode` AS 'Code' FROM `tblusers` u WHERE u.`isactive`= 1 AND `usrRole` <> 1 AND u.`useremail` = '{$uEml}'";
                $usrS = mysqli_query($connection,$ssql);
                if(mysqli_num_rows($usrS) > 0){
                    while($ussrs = mysqli_fetch_assoc($usrS)){
                        $uC = base64_encode(trim($ussrs['Code']));
                        $ws = str_replace('=', '', $uC);
                        $userCode = $ws;
                        $uId = $ussrs['User'];
                    }
                    $expDate = date('Y-m-d h:i:s', strtotime($currDate. ' + 3 days'));
                    $usql = "UPDATE `tblusers` SET `userPswd`='',`lastNotifOn`='{$expDate}',`isactive`= 0 WHERE `userId` = {$uId}";
                    mysqli_query($connection,$usql);
                    $response = $userCode.'|1';
                }
                else{
                    $response = $userCode.'|-1';
                }                
            }
            catch(Exception $ex){
                //pass to logs
                $response = $ex->getMessage().'|0';
            }
            finally{
                $dataObj->CloseConnection($connection);
            }
            return $response;
    }

    function Status($user = Array()){
        date_default_timezone_set('Asia/Colombo');
        $currDate = date('Y-m-d h:i:s');
        $response = 0;
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            try{
                $uId = '';
                $uEml = trim($user['username']);
                $userCode = base64_decode(trim($user['userC']).'=');
                $userPwds = hash('sha512',trim($user['usrpwd']),false);
                $userK = '';

                $ssql = "SELECT DISTINCT u.`userId` AS 'User', u.`name` AS 'Name' FROM `tblusers` u WHERE u.`useremail` = '{$uEml}' AND u.`actCode` = '{$userCode}' AND u.`lastNotifOn` < '{$currDate}'";
                $usrS = mysqli_query($connection,$ssql);
                if(mysqli_num_rows($usrS) > 0){
                    while($ussrs = mysqli_fetch_assoc($usrS)){
                        $userK = trim($ussrs['Code']);
                        $uId = trim($ussrs['User']);
                    }

                    $usql = "UPDATE `tblusers` SET `userPswd`='{$userPwds}',`lastNotifOn`='{$currDate}',`isactive`= 1 WHERE `userId` = {$uId}";
                    mysqli_query($connection,$usql);
                    $response = 1;
                }
                else{
                    $response = -1;
                }                
            }
            catch(Exception $ex){
                //pass to logs
                $response = $ex->getMessage();
                $response = 0;
            }
            finally{
                $dataObj->CloseConnection($connection);
            }
            return $response;
    }

    function UpdateProfile($profile = Array()){
        date_default_timezone_set('Asia/Colombo');
        $currDate = date('Y-m-d h:i:s');
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $uEml = trim($profile['username']);
            $uPwd = trim($profile['userpwd']);
            $uNPwd = trim($profile['nwpaswd']);
            $actKey = $dataObj->GeneratePerma(12);
            $uPswd = hash('sha512',trim($uPwd),false);
            $uNPswd = hash('sha512',trim($uNPwd),false);
            $uId = '';
            $userCode = '';

            $ssql = "SELECT DISTINCT u.`userId` AS 'User' FROM `tblusers` u WHERE u.`isactive`= 1 AND u.`useremail` = '{$uEml}' AND u.`userPswd` = '{$uPswd}'";
            $usrS = mysqli_query($connection,$ssql);
            if(mysqli_num_rows($usrS) > 0){
                while($ussrs = mysqli_fetch_assoc($usrS)){
                    $uC = base64_encode(trim($actKey));
                    //$ws = str_replace('=', '', $uC);
                    $userCode = $uC;
                    $uId = $ussrs['User'];
                }
                $expDate = date('Y-m-d h:i:s', strtotime($currDate. ' + 3 days'));
                $usql = "UPDATE `tblusers` SET `userPswd`='{$uNPswd}',`actCode` = '{$userCode}',`lastNotifOn`='{$expDate}',`isactive`= 1 WHERE `userId` = {$uId}";
                mysqli_query($connection,$usql);
                $response = $userCode.'|1';
            }
            else{
                $response = $userCode.'|-1';
            }                
        }
        catch(Exception $ex){
            //pass to logs
            $response = $ex->getMessage().'|0';
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }

}
?>
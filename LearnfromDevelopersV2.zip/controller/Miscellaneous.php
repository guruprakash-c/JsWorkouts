<?php
class Miscellaneous{
 function Consent(){
    $currUri = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $uriChunks = parse_url($currUri);
    $host = $uriChunks['host'];
    if (!isset($_COOKIE[$host])) {
        setcookie($host,$currUri,((24*60*60)*31),$uriChunks['path'],$uriChunks['host']);
    }
 }
}
?>
<?php 
require "./model/Tasks.php";

class Task{
    function AddTasks(){
        $response = null;
        $task = new Tasks();
        $response = $task->TaskBackup();
        return $response;
    }
    function Restore(){
        $response = null;
        $task = new Tasks();
        $response = $task->DeActivateTasks();
        return $response;
    }
}
?>
<meta name="robots" content="noindex">
<?php 
    header('Location: ../index.php');
?>
<?php 
error_reporting(0);
require_once "./controller/Miscellaneous.php";
$misc = new Miscellaneous();
$misc->Consent();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Follow us &ndash; Learn from Developers</title>
    <?php require_once "./layouts/head.php"; ?>
</head>
<body>
<noscript>
<div class="alert alert-danger" role="alert">Please enable Javascript in your browser to avoid inconvenience.</div>
</noscript>
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <main class="container mt-4" style="margin-top: 7em !important;">
        <section class="row mt-0">
            <div class="col-md-12 md-offset-4">
                <h4 class="display-3">
                    Hey Developers,
                </h4>
                <h5 class="display-4">A short summary about our website.</h5>
                <p class="h5">Learn from Developers is a place where you can share your articles and videos. This is one of the places where you can get the articles/videos related your programming skills.</p>
                <p class="h5">There are nothing to say specially :)</p>
            </div>
        </section>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
</body>

</html>
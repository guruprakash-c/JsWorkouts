<div class="modal fade" id="forgotmdl" tabindex="-1" data-backdrop="static" role="dialog" aria-labelledby="forgotmdlLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content shadow">
                    <div class="modal-header">
                        <h5 class="modal-title" id="forgotmdlLabel">Get your password</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body container-fluid">
                        <form name="forgotform" id="forgotform" method="POST" enctype="multipart/form-data">
                            <section class="row mt-0">
                                <div class="col-md-12">
                                    <div class="form-group mt-2 mb-2">
                                        <label for="fEmail">Email address <span class="text-danger">*</span></label>
                                        <input type="email" name="fEmail" id="fEmail" placeholder="Email address"
                                            class="form-control form-control-sm" maxlength="100"
                                            oninvalid="this.setCustomValidity('Please enter your email address')"
                                            oninput="this.setCustomValidity('')" required />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group mt-2 mb-2">
                                        <button type="submit" class="btn btn-success btn-block btn-sm">
                                            Send Password <span class="fa fa-arrow-right"></span> 
                                        </button>
                                    </div>
                                </div>
                            </section>
                        </form>
                    </div>
                    <div class="modal-footer"></div>
                </div>
            </div>
        </div>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<noscript><style>.container{display:none !important;}</style></noscript>
<link rel="shortcut icon" href="./assets/learnfromdevelopers-icon.svg" />
<link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
<link rel="stylesheet" href="./assets/bootstrap.css" />
<link rel="stylesheet" href="./assets/theme.css" />
<link rel="stylesheet" href="./assets/style.css" />
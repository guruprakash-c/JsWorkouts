<?php 
require_once "./controller/Author.php";
require_once "./controller/Category.php";
require_once "./controller/Posts.php";

$postData = new Posts();
$authData = new Author();
$cagyData = new Category();
?>
<div class="row">
        <div class="col-12 col-md">
            <img src="./assets/learnfromdevelopers-flogo.svg"
                style="background: rgba(25, 118, 210, 1) !important;width: 100px; height: 100px; vertical-align: middle;"
                class="img-thumbnail border-0" />
            <p class="d-block mb-3">&copy; <?=((date('Y')-20).' - '.date('Y')) ?></p>
            <p>
                <a href="//www.dmca.com/Protection/Status.aspx?ID=dc4d6e01-375f-478e-9822-3b47b9d072da" title="DMCA.com Protection Status" target="_blank" class="dmca-badge"> <img src="https://images.dmca.com/Badges/dmca-badge-w100-5x1-08.png?ID=dc4d6e01-375f-478e-9822-3b47b9d072da" target="_blank" alt="DMCA.com Protection Status" /></a>
                <script src="https://images.dmca.com/Badges/DMCABadgeHelper.min.js"></script>
            </p>
        </div>
        <div class="col-6 col-md ">
            <h5>Top Categories</h5>
            <?php 
                $cagys = $cagyData->TopCategories(5);
                if(mysqli_num_rows($cagys)>0){
                    echo '<ul class="list-unstyled text-small">';     
                    while($cDtls = mysqli_fetch_assoc($cagys)){
                        echo '<li><a class="text-primary" href="./categories.php?c='.str_replace(' ','',$cDtls["Category"]).'">'.$cDtls["Category"].'</a></li>';           
                    }     
                    echo '</ul>';
                }
            ?>
            <a href="./categories.php">more &raquo;</a>
        </div>
        <div class="col-6 col-md">
            <h5>Authors</h5>
            <?php 
                $authors = $authData->TopAuthors(5);
                if(mysqli_num_rows($authors) > 0){
                    echo '<ul class="list-unstyled text-small">';     
                    while($aDtls = mysqli_fetch_assoc($authors)){
                        echo '<li><a class="text-primary" href="./authors.php?a='.str_replace(' ','',$aDtls["Author"]).'">'.$aDtls["Author"].'</a></li>';           
                    }     
                    echo '</ul>';
                }
            ?>
            <a href="./authors.php">more &raquo;</a>
        </div>
        <div class="col-6 col-md">
            <h5>Archives</h5>
                <?php 
                    $posts = $postData->TopPosts(5);
                    if(mysqli_num_rows($posts)>0){
                       echo '<ul class="list-unstyled text-small">';     
                        while($pDtls = mysqli_fetch_assoc($posts)){
                            echo '<li><a class="text-primary" href="./archives.php?year='.$pDtls["Date"].'">'.$pDtls["Date"].'</a></li>';           
                        }     
                       echo '</ul>';
                    }
                ?>
            <a href="./archives.php">more &raquo;</a>
        </div>
        <div class="col-6 col-md">
            <h5>About</h5>
            <ul class="list-unstyled text-small">
                <li><a class="text-primary" href="#" target="_blank">Our Community</a></li>
                <li><a class="text-primary" href="./follow-us.php">Follow Us</a></li>
                <li><a class="text-primary" href="./about.php">About</a></li>
                <li><a class="text-primary" href="./privacy.php">Privacy</a></li>
                <li><a class="text-primary" href="./terms.php">Terms</a></li>
            </ul>
        </div>
    </div>
    <div class="gototop js-top float-right">
        <button type="button" class="js-gotop btn btn-dark"><i class="fa fa-arrow-up"></i></button>
    </div>
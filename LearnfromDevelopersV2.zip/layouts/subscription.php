<div class="modal fade" id="subscribemdl" tabindex="-1" data-backdrop="static" role="dialog" aria-labelledby="subscribemdlLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content shadow">
                    <div class="modal-header">
                        <h5 class="modal-title" id="subscribemdlLabel">Fill the details</h5>
                    </div>
                    <div class="modal-body container-fluid">
                        <form name="subscribeform" id="subscribeform" method="POST" enctype="multipart/form-data">
                            <section class="row mt-0">
                                <div class="col-md-12">
                                    <div class="form-group mt-2 mb-2">
                                        <label for="uName">Name <span class="text-danger">*</span></label>
                                        <input type="text" name="uName" id="uName" placeholder="Your name"
                                            class="form-control form-control-sm" maxlength="300"
                                            oninvalid="this.setCustomValidity('Please enter your name')"
                                            oninput="this.setCustomValidity('')" required />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group mt-2 mb-2">
                                        <label for="uEmail">Email address <span class="text-danger">*</span></label>
                                        <input type="email" name="uEmail" id="uEmail" placeholder="Email address"
                                            class="form-control form-control-sm" maxlength="300"
                                            oninvalid="this.setCustomValidity('Please enter your email address')"
                                            oninput="this.setCustomValidity('')" required />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group mt-2 mb-2">
                                        <button type="submit" class="btn btn-primary btn-block btn-sm">
                                            Submit <span class="fa fa-arrow-right"></span>
                                        </button>
                                    </div>
                                </div>
                            </section>
                        </form>
                    </div>
                    <div class="modal-footer"></div>
                </div>
            </div>
        </div>
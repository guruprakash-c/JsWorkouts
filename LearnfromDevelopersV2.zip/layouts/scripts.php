<script src="./assets/jquery.js"></script>
<script src="./assets/popper.js"></script>
<script src="./assets/bootstrap.js"></script>
<script src="./assets/scroll.js"></script>
<script src="./assets/notify.js"></script>
<script src="./assets/custom.js"></script>
<script>
$('button.js-gotop').click(function (e) {
    e.preventDefault();
    $('body,html').animate({
        scrollTop: 0
    }, 1000);
    return false;
});
$('.tox-notifications-container').css({'display':'none !important'});
</script>
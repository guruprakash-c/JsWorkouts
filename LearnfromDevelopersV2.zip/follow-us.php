<?php 
error_reporting(0);

require_once "./controller/Log.php";
require_once "./controller/Miscellaneous.php";
$misc = new Miscellaneous();
$misc->Consent();

$log = new Log();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Follow us &ndash; Learn from Developers</title>
    <?php require_once "./layouts/head.php"; ?>
</head>
<body>
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <main class="container mt-4" style="margin-top: 7em !important;">
        <section class="row mt-0">
            <div class="col-md-12 md-offset-4 lead">
                <h2 class="h4">You can follow us at:</h2>
                <ul class="list-inline">
                    <li class="list-inline-item badge badge-primary"><a href="#" target="_blank" class="text-white"><span class="fa fa-facebook"></span>&nbsp;Facebook</a></li>
                    <li class="list-inline-item badge badge-info"><a href="#" target="_blank" class="text-white"><span class="fa fa-twitter"></span>&nbsp;Twitter</a></li>
                    <li class="list-inline-item badge badge-danger"><a href="#" target="_blank" class="text-white"><span class="fa fa-youtube"></span>&nbsp;YouTube</a></li>
                    <li class="list-inline-item badge badge-warning"><a href="#" target="_blank" class="text-white"><span class="fa fa-instagram"></span>&nbsp;Instagram</a></li>
                    <li class="list-inline-item badge badge-danger"><a href="#" target="_blank" class="text-white"><span class="fa fa-pinterest"></span>&nbsp;Pinterest</a></li>
                </ul>
            </div>
        </section>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
</body>

</html>
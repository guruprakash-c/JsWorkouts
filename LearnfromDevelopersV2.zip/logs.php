<?php 
error_reporting(0);
require_once "./controller/Log.php";
require_once "./controller/Miscellaneous.php";
$misc = new Miscellaneous();
$misc->Consent();

ob_start();
if(!isset($_SESSION)){
session_start();
}
$log = new Log();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Follow us &ndash; Learn from Developers</title>
    <meta name="robots" content="noindex">
    <?php require_once "./layouts/head.php"; ?>
</head>
<body>
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <main class="container mt-4" style="margin-top: 7em !important;">
        <?php 
            if(!empty($_SESSION['laererg'])){
        ?>
        <section class="row mt-0">
            <div class="col-md-12 md-offset-4">
                <?php 
                    $logs = $log->GetLogs("");
                    if(mysqli_num_rows($logs) > 0){
                        echo '<div class="lead"><h3><strong>'.mysqli_num_rows($logs).'</strong> Log(s) captured.</h3></div>';
                        echo '<ul class="list-unstyled">';
                        while($lg = mysqli_fetch_assoc($logs)){
                ?>
                            <li class="media mt-3 mb-3">
                                <?php 
                                    if($lg['Status'] == 1){
                                        echo '<span class="text-success fa fa-check-square-o mr-2 fa-2x"></span>';
                                    }
                                    else{
                                        echo '<span class="text-danger fa fa-window-close-o mr-2 fa-2x"></span>';
                                    }
                                ?>
                                <div class="media-body">
                                    <h5 class="mt-0 mb-1" data-toggle="collapse" href="#<?='log'.$lg['ID']?>" role="button" aria-expanded="false" aria-controls="<?='log'.$lg['ID']?>">
                                        Issue #000<?=$lg['ID']?>
                                    </h5>
                                    <div class="collapse" id="<?='log'.$lg['ID']?>">
                                        <div class="lead">
                                            <dl class="row">
                                                <dt class="col-md-2">Date</dt>
                                                <dd class="col-md-10"><?=$lg['Date'] ?></dd>
                                                <dt class="col-md-2">Page</dt>
                                                <dd class="col-md-10"><a href="<?=$lg['Page'] ?>" target="_blank"><?=$lg['Page'] ?></a></dd>
                                                <dt class="col-md-2">Function</dt>
                                                <dd class="col-md-10"><?=$lg['Function'] ?></dd>
                                                <dt class="col-md-2">Message</dt>
                                                <dd class="col-md-10"><?=$lg['Message'] ?></dd>
                                            </dl>
                                        </div>
                                    </div>
                                </div>
                            </li>
                <?php    
                        }
                        echo '</ul>';
                    }
                    else{
                        echo '<div class="lead"><h3><strong>No</strong> Log(s) captured.</h3></div>';
                    }
                ?>
            </div>
        </section>
        <?php 
            }
            else{
                header("Location: index.php");
            }
        ?>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
</body>

</html>
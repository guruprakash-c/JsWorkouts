<?php 
/*echo $password =  base64_encode('c.guruprakash@yahoo.com');  
$ws = str_replace('=', '', $password);
base64_decode($ws);
echo strlen($password);
//$hash_default_salt = hash('sha512',$password,false); 
   
//echo '<li>'.$hash_default_salt.'</li>';
//password_verify('Password', $hash_default_salt); 
*/
echo hash('sha512',trim('3nszr4ZdJjnB'),false);
//date_default_timezone_set('Asia/Colombo');
//$date = date('Y-m-d h:i:s');
//echo date('Y-m-d h:i:s', strtotime($date. ' + 3 days'));

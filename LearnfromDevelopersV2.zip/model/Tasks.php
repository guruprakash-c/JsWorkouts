<?php 
require_once "DataConfig.php";
require_once "Logs.php";

class Tasks extends DataConfig{
    function TaskBackup(){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        $page = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        try{
            $connection->set_charset("utf8");
            $tables = array();
            $ssql = "SHOW TABLES";
            $tbls = mysqli_query($connection, $ssql);

            while ($tbl = mysqli_fetch_row($tbls)) {
                $tables[] = $tbl[0];
            }
            $scriptData = "";
            foreach ($tables as $t) {
                $tsql = "SHOW CREATE TABLE $t";
                $rs = mysqli_query($connection, $tsql);
                $row = mysqli_fetch_row($rs);
                
                $scriptData .= "\n\n" . $row[1] . ";\n\n";
                
                
                $ssql = "SELECT * FROM $t";
                $rs = mysqli_query($connection, $ssql);
                
                $cols = mysqli_num_fields($rs);
                
                for ($i = 0; $i < $cols; $i ++) {
                    while ($row = mysqli_fetch_row($rs)) {
                        $scriptData .= "INSERT INTO $t VALUES(";
                        for ($j = 0; $j < $cols; $j ++) {
                            $row[$j] = $row[$j];
                            
                            if (isset($row[$j])) {
                                $scriptData .= '"' . $row[$j] . '"';
                            } else {
                                $scriptData .= '""';
                            }
                            if ($j < ($cols - 1)) {
                                $scriptData .= ',';
                            }
                        }
                        $scriptData .= ");\n";
                    }
                }
                $scriptData .= "\n"; 
            } 
            if(!empty($scriptData)){
                $fName = 'Task_'. date('dMYhms') . '.sql';
                $hndlr = fopen('temp/'.$fName, 'w+');
                $numLns = fwrite($hndlr, $scriptData);
                fclose($hndlr);
                header('Content-Description: File Transfer');
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename=' . basename($fName));
                header('Content-Transfer-Encoding: binary');
                header('Expires: 0');
                header('Cache-Control: must-revalidate');
                header('Pragma: public');
                header('Content-Length: ' . filesize($fName));
                ob_clean();
                flush();
                readfile('temp/'.$fName);
                exec('rm '.'temp/'.$fName); 
            }
            else{
                $response = 0;
            }
        }
        catch(Exception $ex){
            $log = new Logs();
            $log->AddLog($ex->getMessage(),$page,"TaskJobs :: Create");
            $response = 2;
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
    function DeActivateTasks(){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        $page = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        try{         
            if ($hndl = opendir('temp/')) {
                while (false !== ($fl = readdir($hndl))) {
                    if ($fl != "." && $fl != "..") {
                        $ext = pathinfo($fl, PATHINFO_EXTENSION);
                        if(strtolower($ext) == 'sql' && strtolower($ext) != 'php'){
                            unlink('temp/'.$fl);
                            $response = 1;
                        }
                        else{
                            $response = 2;
                        }
                    }
                }
                closedir($hndl);
            }
        }
        catch(Exception $ex){
            $log = new Logs();
            $log->AddLog($ex->getMessage(),$page,"TaskJobs :: RemoveTasks");
            $response = 2;
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }

}
?>
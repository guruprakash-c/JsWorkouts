<?php 
require_once "DataConfig.php";
require_once "Logs.php";

class Authors extends DataConfig{

    function Author($authorId=""){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $ssql = "SELECT `authorId` as 'ID', `authorName` as 'Author', `authorBio` as 'Bio', `authorFb` as 'Fb', `authorTw` as 'Tw', `authorSite` as 'Website', `authorAvatar` as 'Photo', `isActive` as 'Status' FROM `tblauthors` WHERE `isActive` = 1 ORDER by `authorName` ASC";
            if(!empty($authorId)){
               $authorId = strtolower($authorId);
               $ssql = "SELECT `authorId` as 'ID', `authorName` as 'Author', `authorBio` as 'Bio', `authorFb` as 'Fb', `authorTw` as 'Tw', `authorSite` as 'Website', `authorAvatar` as 'Photo', `isActive` as 'Status' FROM `tblauthors` WHERE LOWER(`authorName`) = '{$authorId}' ORDER by `authorName` ASC"; 
            }
            $response = mysqli_query($connection,$ssql);
            
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Author :: Get");
            
            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
    function AddAuthor($author = array()){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            
            $name = $author['Author'];
            $bio = $author['Details'];
            $photo = $author['Photo'];
            $fb = $author['FB'];
            $tw = $author['Tw'];
            $site = $author['Website'];

            $isExists = $this->DoesExists(strtolower($name));
            if($isExists == 0){
                $isql = "INSERT INTO `tblauthors`(`authorName`, `authorBio`, `authorFb`, `authorTw`, `authorSite`, `authorAvatar`) VALUES ('{$name}','{$bio}','{$fb}','{$tw}','{$site}','{$photo}')";
                mysqli_query($connection,$isql);
                $response = 1;
            }
            else{
                $response = -1;
            }
            
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Author :: Add");
            
            $response = $ex->getMessage();
        }
        return $response;
    }
    function DoesExists($author){
        $isExists = false;
        
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        
        $chksql = "SELECT * FROM `tblauthors` WHERE Lower(`authorName`) = '{$author}'";
        $data = mysqli_query($connection,$chksql);
        $response = mysqli_num_rows($data);
        
        if($response > 0){
            $isExists = true;
        }
        else{
            $isExists = false;
        }
        return $isExists;
    }
    function UpdateAuthor($author = array()){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $usql = "";
            $response = mysqli_query($usql);
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Author :: Update");
            
            $response = $ex->getMessage();
        }
    }
    function BlockAuthor($authorId){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $bsql = "";
            $response = mysqli_query($bsql);
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Author :: Block");
            
            $response = $ex->getMessage();
        }
    }
    function DeleteAuthor($authorId){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $dsql = "";
            $response = mysqli_query($dsql);
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Author :: Remove");
            
            $response = $ex->getMessage();
        }
    }
    function TopAuthor($limit = 5){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $ssql = "SELECT a.`authorName` as 'Author' FROM tblauthors a WHERE a.`isActive` <> 0 ORDER BY a.`authorName` ASC LIMIT {$limit}"; 
            $response = mysqli_query($connection,$ssql);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Author :: Top");
            
            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
}
?>
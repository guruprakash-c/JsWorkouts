<?php 
require_once "DataConfig.php";
require_once "Logs.php";

class Articles extends DataConfig{

    function Article($articleId=""){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $ssql = "SELECT p.`dop` as 'Date',p.`permaId` as 'ID', p.`articleTitle` as 'Title', a.`authorId` as 'AuthorId', a.`authorName` as 'Author', a.`authorBio` as 'Bio', a.`authorAvatar` as 'AuthorPhoto', a.`authorFb` as 'Facebook', a.`authorTw` as 'Twitter', a.`authorSite` as 'Website', c.`categoryId` as 'CategoryId',c.`categoryName` as 'Category',c.`categoryIcon` as 'Icon',c.`categoryBanner` as 'CategoryPoster', p.`articleSummary` as 'Summary', p.`articleType` as 'Type', p.`articleBody` as 'Description', p.`articleLabels` as 'Keywords', p.`articlePoster` as 'Banner', p.`articleRef` as 'Source', p.`isFeatured` as 'Featured', p.`articleViews` as 'Views', p.`isBlocked` as 'PostStatus' FROM `tblposts` p join tblcategories c on p.`articleCategory` = c.`categoryId` join tblauthors a on p.`articleAuthor` = a.`authorId` WHERE p.`isBlocked` <> 1 and p.`isFeatured` <> 1 ORDER BY p.`dop` DESC";
            if(!empty($articleId)){
               $articleId = strtolower($articleId);
               $ssql = "SELECT p.`dop` as 'Date',p.`permaId` as 'ID', p.`articleTitle` as 'Title', a.`authorId` as 'AuthorId', a.`authorName` as 'Author', a.`authorBio` as 'Bio', a.`authorAvatar` as 'AuthorPhoto', a.`authorFb` as 'Facebook', a.`authorTw` as 'Twitter', a.`authorSite` as 'Website', c.`categoryId` as 'CategoryId',c.`categoryName` as 'Category',c.`categoryIcon` as 'Icon',c.`categoryBanner` as 'CategoryPoster', p.`articleSummary` as 'Summary', p.`articleType` as 'Type', p.`articleBody` as 'Description', p.`articleLabels` as 'Keywords', p.`articlePoster` as 'Banner', p.`articleRef` as 'Source', p.`isFeatured` as 'Featured', p.`articleViews` as 'Views', p.`isBlocked` as 'PostStatus' FROM `tblposts` p join tblcategories c on p.`articleCategory` = c.`categoryId` join tblauthors a on p.`articleAuthor` = a.`authorId` WHERE p.`isBlocked` <> 1 and p.`permaId` = '{$articleId}' ORDER BY p.`dop` DESC"; 
            }
            $response = mysqli_query($connection,$ssql);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Articles :: Post");

            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
    function ArticlesByYear($year){
        $response = null;
        if(!empty($year)){    
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $ysql = "SELECT p.`permaId` as 'ID', p.`articleTitle` as 'Title' FROM `tblposts` p  WHERE  p.`isBlocked` <> 1 AND YEAR(p.`dop`) = '{$year}' ORDER BY p.`dop` ASC";
            $response = mysqli_query($connection,$ysql);
        }
        
        return $response;
    }
    function RelatedArticle($articleId,$categoryId){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $ssql = "SELECT p.`dop` as 'Date',p.`permaId` as 'ID', p.`articleTitle` as 'Title', a.`authorId` as 'AuthorId', a.`authorName` as 'Author', a.`authorBio` as 'Bio', a.`authorAvatar` as 'AuthorPhoto', a.`authorFb` as 'Facebook', a.`authorTw` as 'Twitter', a.`authorSite` as 'Website', c.`categoryId` as 'CategoryId',c.`categoryName` as 'Category',c.`categoryIcon` as 'Icon',c.`categoryBanner` as 'CategoryPoster', p.`articleSummary` as 'Summary', p.`articleType` as 'Type', p.`articleBody` as 'Description', p.`articleLabels` as 'Keywords', p.`articlePoster` as 'Banner', p.`articleRef` as 'Source', p.`isFeatured` as 'Featured', p.`articleViews` as 'Views', p.`isBlocked` as 'PostStatus' FROM `tblposts` p join tblcategories c on p.`articleCategory` = c.`categoryId` join tblauthors a on p.`articleAuthor` = a.`authorId` WHERE p.`isBlocked` <> 1 AND p.`permaId` <> '{$articleId}' AND p.`articleCategory` = {$categoryId} ORDER BY p.`dop` ASC LIMIT 3";
            $exactResp = mysqli_query($connection,$ssql);
            if(mysqli_num_rows($exactResp)>0){ 
                $response = mysqli_query($connection,$ssql);
            }
            else{
                $ssql = "SELECT p.`dop` as 'Date',p.`permaId` as 'ID', p.`articleTitle` as 'Title', a.`authorId` as 'AuthorId', a.`authorName` as 'Author', a.`authorBio` as 'Bio', a.`authorAvatar` as 'AuthorPhoto', a.`authorFb` as 'Facebook', a.`authorTw` as 'Twitter', a.`authorSite` as 'Website', c.`categoryId` as 'CategoryId',c.`categoryName` as 'Category',c.`categoryIcon` as 'Icon',c.`categoryBanner` as 'CategoryPoster', p.`articleSummary` as 'Summary', p.`articleType` as 'Type', p.`articleBody` as 'Description', p.`articleLabels` as 'Keywords', p.`articlePoster` as 'Banner', p.`articleRef` as 'Source', p.`isFeatured` as 'Featured', p.`articleViews` as 'Views', p.`isBlocked` as 'PostStatus' FROM `tblposts` p join tblcategories c on p.`articleCategory` = c.`categoryId` join tblauthors a on p.`articleAuthor` = a.`authorId` WHERE p.`isBlocked` <> 1 AND p.`permaId` <> '{$articleId}' ORDER BY p.`dop` ASC LIMIT 3"; 
                $response = mysqli_query($connection,$ssql);
            }
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Articles :: Related Post");
            
            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
    function FeaturedArticle(){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $ssql = "SELECT p.`dop` as 'Date',p.`permaId` as 'ID', p.`articleTitle` as 'Title', a.`authorId` as 'AuthorId', a.`authorName` as 'Author', a.`authorBio` as 'Bio', a.`authorAvatar` as 'AuthorPhoto', a.`authorFb` as 'Facebook', a.`authorTw` as 'Twitter', a.`authorSite` as 'Website', c.`categoryId` as 'CategoryId',c.`categoryName` as 'Category',c.`categoryIcon` as 'Icon',c.`categoryBanner` as 'CategoryPoster', p.`articleSummary` as 'Summary', p.`articleType` as 'Type', p.`articleBody` as 'Description', p.`articleLabels` as 'Keywords', p.`articlePoster` as 'Banner', p.`articleRef` as 'Source', p.`isFeatured` as 'Featured', p.`articleViews` as 'Views', p.`isBlocked` as 'PostStatus' FROM `tblposts` p join tblcategories c on p.`articleCategory` = c.`categoryId` join tblauthors a on p.`articleAuthor` = a.`authorId` WHERE p.`isBlocked` <> 1 AND p.`isFeatured` = 1 ORDER BY RAND() LIMIT 1";
            $response = mysqli_query($connection,$ssql);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Articles :: Featured Post");
            
            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
    function AddPost($articlePost = array()){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            
            $category = $articlePost['Category'];
            $author = $articlePost['Author'];
            $type = $articlePost['Type'];
            $title = $articlePost['Title'];
            $summary = $articlePost['Summary'];
            $description = $articlePost['Description'];
            $keywords = $articlePost['Keywords'];
            $poster = $articlePost['Poster'];
            $source = $articlePost['Source'];
            $perma = $dataObj->GeneratePerma(5);

            $byImporter = $articlePost['Status'];

            $isExists = $this->DoesExists($source);
            if($isExists == 0){
                $isql = "INSERT INTO `tblposts`(`permaId`, `articleTitle`, `articleAuthor`, `articleCategory`, `articleSummary`, `articleType`, `articleBody`, `articleLabels`, `articlePoster`, `articleRef`) VALUES ('{$perma}','{$title}',{$author},{$category},'{$summary}','{$type}','{$description}','{$keywords}','{$poster}','{$source}')";
                if((!empty($byImporter)) && ($byImporter == 'tool')){
                    $isql = "INSERT INTO `tblposts`(`permaId`, `articleTitle`, `articleAuthor`, `articleCategory`, `articleSummary`, `articleType`, `articleBody`, `articleLabels`, `articlePoster`, `articleRef`,`isBlocked`) VALUES ('{$perma}','{$title}',{$author},{$category},'{$summary}','{$type}','{$description}','{$keywords}','{$poster}','{$source}',1)";
                }
                mysqli_query($connection,$isql);
                $response = 1;
            }
            else{
                $response = -1;
            }
            
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Articles :: Add Post");
            
            $response = $ex->getMessage()??0;
        }
        return $response;
    }
    function DoesExists($articleUri){
        $isExists = false;
        
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        
        $chksql = "SELECT * FROM `tblposts` WHERE `articleRef` = '{$articleUri}'";
        $data = mysqli_query($connection,$chksql);
        $response = mysqli_num_rows($data);
        
        if($response > 0){
            $isExists = true;
        }
        else{
            $isExists = false;
        }
        return $isExists;
    }
    function UpdateArticlePost($articlePost = array()){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $usql = "";
            $response = mysqli_query($usql);
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Articles :: Update Post");
            
            $response = $ex->getMessage();
        }
    }
    function BlockArticlePost($articleId){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $bsql = "";
            $response = mysqli_query($bsql);
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Articles :: Block Post");
            
            $response = $ex->getMessage();
        }
    }
    function DeleteArticlePost($articleId){
        $response = 0;
        try{
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $dsql = "";
            $response = mysqli_query($dsql);
            $dataObj->CloseConnection($connection);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Articles :: Delete Post");
            
            $response = $ex->getMessage();
        }
    }
    function Search($keywords="",$category="",$author=""){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $ssql = "";
            if(!empty($keywords)){
               $ssql = "SELECT DISTINCT p.`dop` as 'Date',p.`permaId` as 'ID', p.`articleTitle` as 'Title', a.`authorId` as 'AuthorId', a.`authorName` as 'Author', a.`authorBio` as 'Bio', a.`authorAvatar` as 'AuthorPhoto', a.`authorFb` as 'Facebook', a.`authorTw` as 'Twitter', a.`authorSite` as 'Website', c.`categoryId` as 'CategoryId',c.`categoryName` as 'Category',c.`categoryIcon` as 'Icon',c.`categoryBanner` as 'CategoryPoster', p.`articleSummary` as 'Summary', p.`articleType` as 'Type', p.`articleBody` as 'Description', p.`articleLabels` as 'Keywords', p.`articlePoster` as 'Banner', p.`articleRef` as 'Source', p.`isFeatured` as 'Featured', p.`articleViews` as 'Views', p.`isBlocked` as 'PostStatus' FROM `tblposts` p join tblcategories c on p.`articleCategory` = c.`categoryId` join tblauthors a on p.`articleAuthor` = a.`authorId` WHERE LOWER(p.`articleTitle`) LIKE '%{$keywords}%' OR LOWER(p.`articleSummary`) LIKE '%{$keywords}%' OR LOWER(p.`articleType`) LIKE '%{$keywords}%' OR LOWER(p.`articleBody`) LIKE '%{}%' OR LOWER(p.`articleLabels`) LIKE '%{$keywords}%' OR LOWER(p.`articlePoster`) LIKE '%{$keywords}%' OR LOWER(p.`articleRef`) LIKE '%{$keywords}%' ORDER BY p.`dop` DESC";
            }
            else if(!empty($category)){
               $c = str_replace(' ','',$category); 
               $ssql = "SELECT p.`dop` as 'Date',p.`permaId` as 'ID', p.`articleTitle` as 'Title', a.`authorId` as 'AuthorId', a.`authorName` as 'Author', a.`authorBio` as 'Bio', a.`authorAvatar` as 'AuthorPhoto', a.`authorFb` as 'Facebook', a.`authorTw` as 'Twitter', a.`authorSite` as 'Website', c.`categoryId` as 'CategoryId',c.`categoryName` as 'Category',c.`categoryIcon` as 'Icon',c.`categoryBanner` as 'CategoryPoster', p.`articleSummary` as 'Summary', p.`articleType` as 'Type', p.`articleBody` as 'Description', p.`articleLabels` as 'Keywords', p.`articlePoster` as 'Banner', p.`articleRef` as 'Source', p.`isFeatured` as 'Featured', p.`articleViews` as 'Views', p.`isBlocked` as 'PostStatus' FROM `tblposts` p join tblcategories c on p.`articleCategory` = c.`categoryId` join tblauthors a on p.`articleAuthor` = a.`authorId` WHERE REPLACE(c.`categoryName`,' ','') = '{$c}' OR LOWER(p.`articleLabels`) like LOWER('%{$c}%') ORDER BY p.`dop` DESC"; 
            }
            else if(!empty($author)){
               $a = str_replace(' ','',$author);
               $ssql = "SELECT DISTINCT p.`dop` as 'Date',p.`permaId` as 'ID', p.`articleTitle` as 'Title', a.`authorId` as 'AuthorId', a.`authorName` as 'Author', a.`authorBio` as 'Bio', a.`authorAvatar` as 'AuthorPhoto', a.`authorFb` as 'Facebook', a.`authorTw` as 'Twitter', a.`authorSite` as 'Website', c.`categoryId` as 'CategoryId',c.`categoryName` as 'Category',c.`categoryIcon` as 'Icon',c.`categoryBanner` as 'CategoryPoster', p.`articleSummary` as 'Summary', p.`articleType` as 'Type', p.`articleBody` as 'Description', p.`articleLabels` as 'Keywords', p.`articlePoster` as 'Banner', p.`articleRef` as 'Source', p.`isFeatured` as 'Featured', p.`articleViews` as 'Views', p.`isBlocked` as 'PostStatus' FROM `tblposts` p join tblcategories c on p.`articleCategory` = c.`categoryId` join tblauthors a on p.`articleAuthor` = a.`authorId` WHERE REPLACE(a.`authorName`, ' ', '') = '{$a}' ORDER BY p.`dop` DESC"; 
            }
            else{
                $ssql = "SELECT null";
            }

            $response = mysqli_query($connection,$ssql);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Articles :: Search Article");
            
            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
    function TopArticle($limit=5){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $ssql = "SELECT DISTINCT YEAR(p.`dop`) as 'Date' from tblposts p WHERE p.`isBlocked` <> 1 ORDER BY p.`dop` ASC LIMIT {$limit}"; 
            $response = mysqli_query($connection,$ssql);
        }
        catch(Exception $ex){
            //pass to logs
            $log = new Logs();
            $currPg = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $log->AddLog($ex,$currPg,"Articles :: Top Article");
            
            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
    function UserViews($id){
        $response = null;
        if(!empty($id)){    
            $dataObj = new DataConfig();
            $connection = $dataObj->Connection();
            $usql = "";
            $response = mysqli_query($connection,$usql);
        }
    }
}
?>
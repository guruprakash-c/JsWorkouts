<?php 
require_once "DataConfig.php";

class Logs extends DataConfig{
 function AddLog($log,$page,$func){
    if(!empty($log)){
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        $isql = "INSERT INTO `tbllogs`(`functionName`,`pageUrl`, `logMessage`) VALUES ('{$func}','{$page}','{$log}')";
        mysqli_query($connection,$isql);
    }
 }
 function Log($logId){
        $response = 0;
        $dataObj = new DataConfig();
        $connection = $dataObj->Connection();
        try{
            $ssql = "SELECT l.`logId` as 'ID', l.`occurredDate` as 'Date',l.`functionName` as 'Function', l.`pageUrl` as 'Page', l.`logMessage` as 'Message', l.`isResolved` as 'Status' FROM `tbllogs` l ORDER BY l.`occurredDate` DESC";
            if(!empty($logId)){
               $lId = trim($logId);
               $ssql = "SELECT l.`logId` as 'ID', l.`occurredDate` as 'Date',l.`functionName` as 'Function', l.`pageUrl` as 'Page', l.`logMessage` as 'Message', l.`isResolved` as 'Status' FROM `tbllogs` l WHERE l.`logId` = {$lId} ORDER BY l.`occurredDate` DESC"; 
            }
            $response = mysqli_query($connection,$ssql);
        }
        catch(Exception $ex){
            //pass to logs
            $response = $ex->getMessage();
        }
        finally{
            $dataObj->CloseConnection($connection);
        }
        return $response;
    }
}
?>
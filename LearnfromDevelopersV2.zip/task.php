<?php 
ob_start();
if(!isset($_SESSION)){
    session_start();
} 
error_reporting(0);
require_once "./controller/Task.php";
$taskObj = new Task();

require_once "./controller/Miscellaneous.php";
$misc = new Miscellaneous();
$misc->Consent();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Tasks &ndash; Learn from Developers</title>
    <meta name="robots" content="noindex">
    <?php require_once "./layouts/head.php"; ?>
</head>
<body>
<noscript>
<div class="alert alert-danger" role="alert">Please enable Javascript in your browser to avoid inconvenience.</div>
</noscript>
    <header>
        <?php require_once "./layouts/header.php"; ?>
    </header>
    <main class="container mt-4" style="margin-top: 7em !important;">
        <section class="row mt-0">
                <?php
                if(!empty($_SESSION['laererg'])){
                ?>
                <div class="col-md-6">
                    <h3>Create Your Task</h3>
                    <?php 
                        if(!empty($_POST['title'])){
                            $response = $taskObj->AddTasks();
                            switch ($response) {
                                case 2:
                                    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"><strong>Sorry!</strong> Your task failed. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
                                    break;
                                case 0:
                                    echo '<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong>Sorry!</strong> Your task failed. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
                                    break;
                                case 1:
                                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert"><strong>Congratulations!</strong> Your Task has been created, please check your inbox to activate your task. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
                                    break;
                            }
                        }
                        else{
                    ?>
                    <form name="taskform" id="taskform" method="POST" enctype="multipart/form-data">
                        <section class="form-group">
                            <label for="tile">Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" id="title" class="form-control" placeholder="Task Title" required/> 
                        </section>
                        <section class="form-group">
                            <button type="submit" class="btn btn-outline-primary btn-lg">Start Task</button>
                            <button type="reset" class="btn btn-warning btn-lg">Cancel</button>
                        </section>
                    </form>
                    <?php 
                        }   
                    ?>
                </div>
                <div class="col-md-6">
                    <h3>Task Activation</h3>
                    <?php 
                        if(!empty($_POST['code'])){
                            $response2 = $taskObj->Restore();
                            switch ($response2) {
                                case 2:
                                    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert"><strong>Sorry!</strong> Your task code expired. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
                                    break;
                                case 0:
                                    echo '<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong>Sorry!</strong> Your task code failed to activate. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
                                    break;
                                case 1:
                                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert"><strong>Congratulations!</strong> Your Task has been activated. <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
                                    break;
                            }
                        }
                    ?>
                    <form name="activateform" id="activateform" method="POST" enctype="multipart/form-data">
                        <section class="form-group">
                            <label for="code">Code <span class="text-danger">*</span></label>
                            <input type="text" name="code" id="code" class="form-control" placeholder="Task Code" required/> 
                        </section>
                        <section class="form-group">
                            <button type="submit" class="btn btn-primary btn-lg">Activate Task</button>
                        </section>
                    </form>
                </div>
                <?php    
                }
                else{
                    header('Location: index.php');
                }
                ?>
        </section>
    </main>
    <footer class="container-fluid py-5">
        <?php require_once "./layouts/footer.php"; ?>
    </footer>
    <?php require_once "./layouts/scripts.php"; ?>
</body>
</html>
import { Component, OnInit } from '@angular/core';

@Component({
  selector: '.app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  constructor() { }
   
  ngOnInit(): void {
  }
  public copyrightIcoColor = "text-primary";
  generateCopyright(startDate){
    var _d = new Date();
    var currDate = _d.getFullYear();
    var setYear = currDate - startDate;
    return  "Basics of Angular 8 &copy; "+setYear+" &ndash; "+ currDate;
  }

}

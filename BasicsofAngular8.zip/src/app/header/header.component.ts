import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[app-header]',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  public brandColor = "text-muted";
  constructor() { }
  public hasErr = false;
  public mutedText = "";
  public hasVisible = 'none';
  ngOnInit(): void {
  }

  setPlaceHolder(textVal){
    if(textVal != undefined && textVal != ''){
      
      this.mutedText = textVal;
      this.hasErr = true;
      alert('Sorry no result(s) found for "'+this.mutedText+'"');
      this.hasVisible = 'block';
    }
    else{
      this.hasErr = false;
      this.hasVisible = 'none';
      alert('Please enter your keywords to search.');
    }
  }
}
